import 'package:expandable_bottom_sheet/expandable_bottom_sheet.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:pickles_and_pies/common/widgets/login_suggestion_bottomsheet.dart';
import 'package:pickles_and_pies/features/cart/controllers/cart_controller.dart';
import 'package:pickles_and_pies/features/cart/widgets/extra_packaging_widget.dart';
import 'package:pickles_and_pies/features/cart/widgets/not_available_bottom_sheet_widget.dart';
import 'package:pickles_and_pies/features/checkout/controllers/checkout_controller.dart';
import 'package:pickles_and_pies/features/coupon/controllers/coupon_controller.dart';
import 'package:pickles_and_pies/features/profile/controllers/profile_controller.dart';
import 'package:pickles_and_pies/features/splash/controllers/splash_controller.dart';
import 'package:pickles_and_pies/features/store/controllers/store_controller.dart';
import 'package:pickles_and_pies/features/cart/domain/models/cart_model.dart';
import 'package:pickles_and_pies/features/item/domain/models/item_model.dart';
import 'package:pickles_and_pies/features/store/domain/models/store_model.dart';
import 'package:pickles_and_pies/helper/auth_helper.dart';
import 'package:pickles_and_pies/helper/module_helper.dart';
import 'package:pickles_and_pies/helper/price_converter.dart';
import 'package:pickles_and_pies/helper/responsive_helper.dart';
import 'package:pickles_and_pies/helper/route_helper.dart';
import 'package:pickles_and_pies/util/dimensions.dart';
import 'package:pickles_and_pies/util/images.dart';
import 'package:pickles_and_pies/util/styles.dart';
import 'package:pickles_and_pies/common/widgets/custom_app_bar.dart';
import 'package:pickles_and_pies/common/widgets/custom_button.dart';
import 'package:pickles_and_pies/common/widgets/custom_snackbar.dart';
import 'package:pickles_and_pies/common/widgets/footer_view.dart';
import 'package:pickles_and_pies/common/widgets/item_widget.dart';
import 'package:pickles_and_pies/common/widgets/menu_drawer.dart';
import 'package:pickles_and_pies/common/widgets/no_data_screen.dart';
import 'package:pickles_and_pies/common/widgets/web_constrained_box.dart';
import 'package:pickles_and_pies/common/widgets/web_page_title_widget.dart';
import 'package:pickles_and_pies/features/cart/widgets/cart_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pickles_and_pies/features/cart/widgets/web_cart_items_widget.dart';
import 'package:pickles_and_pies/features/home/screens/home_screen.dart';
import 'package:pickles_and_pies/features/store/screens/store_screen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key, required this.fromNav});
  final bool fromNav;

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final ScrollController scrollController = ScrollController();
  GlobalKey<ExpandableBottomSheetState> key = GlobalKey();

  final GlobalKey _widgetKey = GlobalKey();
  double _height = 0;

  @override
  void initState() {
    super.initState();
    initCall();
  }

  Future<void> initCall() async {
    _initialBottomSheetShowHide();
    if(Get.find<CartController>().cartList.isEmpty) {
      await Get.find<CartController>().getCartDataOnline();
    }

    if(Get.find<SplashController>().module == null && Get.find<CartController>().cartList.isNotEmpty) {
      await Get.find<SplashController>().getModules();
      int i = 0;
      for(i = 0; i < Get.find<SplashController>().moduleList!.length; i++){
        if(Get.find<CartController>().cartList[0].item!.moduleId == Get.find<SplashController>().moduleList![i].id){
          break;
        }
      }
      Get.find<SplashController>().setModule(Get.find<SplashController>().moduleList![i]);
      if(!GetPlatform.isWeb) {
        HomeScreen.loadData(true);
      }
    }

    if(Get.find<CartController>().cartList.isNotEmpty){
      if (kDebugMode) {
        print('----cart item : ${Get.find<CartController>().cartList[0].toJson()}');
      }

      if(Get.find<CartController>().addCutlery){
        Get.find<CartController>().updateCutlery(willUpdate: false);
      }
      if(Get.find<CartController>().needExtraPackage){
        Get.find<CartController>().toggleExtraPackage(willUpdate: false);
      }
      Get.find<CartController>().setAvailableIndex(-1, willUpdate: false);
      Get.find<StoreController>().getCartStoreSuggestedItemList(Get.find<CartController>().cartList[0].item!.storeId);
      Get.find<StoreController>().getStoreDetails(Store(id: Get.find<CartController>().cartList[0].item!.storeId, name: null), false, fromCart: true);
      Get.find<CartController>().calculationCart();
      showReferAndEarnSnackBar();
    }
  }

  void _initialBottomSheetShowHide() {
    Future.delayed(const Duration(milliseconds: 600), () {
      key.currentState?.expand();
    }).then((_) {
      Future.delayed(const Duration(seconds: 3), () {
        key.currentState?.contract();
      });
    });

    if(AuthHelper.isGuestLoggedIn() && (GetPlatform.isAndroid || GetPlatform.isIOS)) {
      Future.delayed(const Duration(milliseconds: 3000), () {
        if(Get.currentRoute == RouteHelper.cart && Get.isBottomSheetOpen == false) {
          Get.bottomSheet(LoginSuggestionBottomSheet(fromCartPage: true), isScrollControlled: true);
        }
      });
    }
  }

  void _getExpandedBottomSheetHeight() {
    if (_widgetKey.currentContext != null) {
      final RenderBox renderBox = _widgetKey.currentContext!.findRenderObject() as RenderBox;
      final size = renderBox.size;

      setState(() {
        _height = size.height;
      });
    }
  }

  void _onExpanded() {
    _getExpandedBottomSheetHeight();
  }

  void _onContracted() {
    setState(() {
      _height = 0;
    });
  }

  @override
  Widget build(BuildContext context) {

    bool isDesktop = ResponsiveHelper.isDesktop(context);

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      appBar: CustomAppBar(title: 'my_cart'.tr, backButton: (isDesktop || !widget.fromNav)),
      endDrawer: const MenuDrawer(),endDrawerEnableOpenDragGesture: false,
      body: GetBuilder<StoreController>(builder: (storeController) {
        return GetBuilder<CartController>(builder: (cartController) {
          return cartController.cartList.isNotEmpty ? Column(children: [

            Expanded(
              child: ExpandableBottomSheet(
                key: key,
                persistentHeader: isDesktop ? const SizedBox() : InkWell(
                  onTap: (){
                    if(cartController.isExpanded){
                      cartController.setExpanded(false);
                      setState(() {
                        key.currentState!.contract();
                      });
                    } else {
                      cartController.setExpanded(true);
                      setState(() {
                        key.currentState!.expand();
                      });
                    }
                  },
                  child: Container(
                    color: Theme.of(context).cardColor,
                    child: Container(
                      constraints: const BoxConstraints.expand(height: 30),
                      decoration: BoxDecoration(
                        color: Theme.of(context).disabledColor.withValues(alpha: 0.3),
                        borderRadius: const BorderRadius.only(topLeft: Radius.circular(Dimensions.radiusDefault), topRight: Radius.circular(Dimensions.radiusDefault)),
                      ),
                      child: Icon(Icons.drag_handle, color: Theme.of(context).hintColor, size: 25),
                    ),
                  ),
                ),

                background: Column(children: [

                  WebScreenTitleWidget(title: 'cart_list'.tr),

                   Expanded(
                    child: SingleChildScrollView(
                      controller: scrollController,
                      padding: isDesktop ? const EdgeInsets.only(
                        top: Dimensions.paddingSizeSmall,
                      ) : EdgeInsets.zero,
                      child: FooterView(
                        child: SizedBox(
                          width: Dimensions.webMaxWidth,
                          child: Column(children: [

                            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              isDesktop ? WebCardItemsWidget(cartList: cartController.cartList) : Expanded(
                                flex: 7,
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                                  WebConstrainedBox(
                                    dataLength: cartController.cartList.length, minLength: 5, minHeight: 0.6,
                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                      Container(
                                        decoration: BoxDecoration(
                                          color: Theme.of(context).cardColor,
                                          boxShadow: !ResponsiveHelper.isMobile(context) ? [const BoxShadow()] : [const BoxShadow(
                                            color: Colors.black12, blurRadius: 10, spreadRadius: 0,
                                          )],
                                        ),
                                        child: ListView.builder(
                                          physics: const NeverScrollableScrollPhysics(),
                                          shrinkWrap: true,
                                          itemCount: cartController.cartList.length,
                                          padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                                          itemBuilder: (context, index) {
                                            return CartItemWidget(cart: cartController.cartList[index], cartIndex: index, addOns: cartController.addOnsList.isNotEmpty ? cartController.addOnsList[index] : [], isAvailable: cartController.availableList.isNotEmpty ? cartController.availableList[index] : false, showDivider: index != cartController.cartList.length - 1);
                                          },
                                        ),
                                      ),

                                      const SizedBox(height: Dimensions.paddingSizeSmall),

                                      Center(
                                        child: TextButton.icon(
                                          onPressed: (){
                                            cartController.forcefullySetModule(cartController.cartList[0].item!.moduleId!);
                                            Get.toNamed(
                                              RouteHelper.getStoreRoute(id: cartController.cartList[0].item!.storeId, page: 'item', slug: Get.find<StoreController>().store?.slug??''),
                                              arguments: StoreScreen(store: Store(id: cartController.cartList[0].item!.storeId), fromModule: false),
                                            );
                                            Get.offNamed(RouteHelper.getStoreRoute(id: cartController.cartList[0].item!.storeId, page: 'item', slug: Get.find<StoreController>().store?.slug??''));
                                          },
                                          icon: Icon(Icons.add_circle_outline_sharp, color: Theme.of(context).primaryColor),
                                          label: Text('add_more_items'.tr, style: robotoMedium.copyWith(color: Theme.of(context).primaryColor, fontSize: Dimensions.fontSizeDefault)),
                                        ),
                                      ),

                                      ExtraPackagingWidget(cartController: cartController),

                                      !isDesktop ? suggestedItemView(cartController.cartList) : const SizedBox(),

                                    ]),
                                  ),
                                  const SizedBox(height: Dimensions.paddingSizeSmall),

                                  !isDesktop ? pricingView(cartController, cartController.cartList[0].item!) : const SizedBox(),

                                ]),
                              ),
                              isDesktop ? const SizedBox(width: Dimensions.paddingSizeLarge) : const SizedBox(),

                              isDesktop ? Expanded(flex: 4, child: pricingView(cartController, cartController.cartList[0].item!)) : const SizedBox(),
                            ]),

                            // isDesktop ? WebSuggestedItemViewWidget(cartList: cartController.cartList) : const SizedBox(),
                            // const SizedBox(height: Dimensions.paddingSizeExtraOverLarge),

                          ]),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: _height),

                ]),

                onIsExtendedCallback: _onExpanded,
                onIsContractedCallback: _onContracted,

                expandableContent: isDesktop ? const SizedBox() : Container(
                  width: context.width,
                  key: _widgetKey,
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: const BorderRadius.only(topLeft: Radius.circular(Dimensions.radiusDefault), topRight: Radius.circular(Dimensions.radiusDefault)),
                  ),
                  child: Column(children: [
                    Container(
                      padding: const EdgeInsets.only(
                        left: Dimensions.paddingSizeSmall, right: Dimensions.paddingSizeSmall, top: Dimensions.paddingSizeSmall,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: const BorderRadius.only(topLeft: Radius.circular(Dimensions.radiusDefault), topRight: Radius.circular(Dimensions.radiusDefault)),
                      ),
                      child: Column(children: [
                        // Merge "Item Price" and "Variations" into a single line.
                        // The user wants the total of (item price + variations) shown
                        // under one "item_price" label instead of two separate rows.
                        // We only fold the variations into this row when the module
                        // is the new (food) variation module, because the legacy
                        // variation module already bakes the variation price into
                        // itemPrice and exposing the variations row would double count.
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Text('item_price'.tr, style: robotoRegular),
                          PriceConverter.convertAnimationPrice(
                            (cartController.variationPrice > 0 &&
                                    ModuleHelper.getModuleConfig(
                                            cartController.cartList.first.item!.moduleType)
                                        .newVariation!)
                                ? cartController.itemPrice + cartController.variationPrice
                                : cartController.itemPrice,
                            textStyle: robotoRegular,
                          ),
                        ]),
                        const SizedBox(height: Dimensions.paddingSizeSmall),

                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Text('discount'.tr, style: robotoRegular),
                          storeController.store != null ? Row(children: [
                            Text('(-)', style: robotoRegular),
                            PriceConverter.convertAnimationPrice(cartController.itemDiscountPrice, textStyle: robotoRegular),
                          ]) : Text('calculating'.tr, style: robotoRegular),
                        ]),
                        SizedBox(height: Get.find<SplashController>().configModel!.moduleConfig!.module!.addOn! ? Dimensions.paddingSizeSmall : 0),

                        Get.find<SplashController>().configModel!.moduleConfig!.module!.addOn! ? Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('addons'.tr, style: robotoRegular),
                            Row(children: [
                              Text('(+)', style: robotoRegular),
                              PriceConverter.convertAnimationPrice(cartController.addOns, textStyle: robotoRegular),
                            ]),
                          ],
                        ) : const SizedBox(),

                      ]),
                    ),

                  ]),
                ),

              ),
            ),

            isDesktop ? const SizedBox.shrink() : CheckoutButton(cartController: cartController, availableList: cartController.availableList),

          ]) : const NoDataScreen(isCart: true, text: '', showFooter: true);
        });
      }),
    );
  }

  Widget pricingView(CartController cartController, Item item){
    bool isDesktop = ResponsiveHelper.isDesktop(context);
    return Container(
      decoration: isDesktop ? BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular( isDesktop ? Dimensions.radiusDefault : Dimensions.radiusSmall),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 5, spreadRadius: 1)],
      ) : null,
      child: GetBuilder<StoreController>(
        builder: (storeController) {
          return Column(children: [

            isDesktop ? ExtraPackagingWidget(cartController: cartController) : const SizedBox(),

            isDesktop ? Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault, vertical: Dimensions.paddingSizeSmall),
                child: Text('order_summary'.tr, style: robotoBold),
              ),
            ) : const SizedBox(),

            !isDesktop && Get.find<SplashController>().getModuleConfig(item.moduleType).newVariation!
            && (storeController.store != null && storeController.store!.cutlery!) ? Container(
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 2, spreadRadius: 1, offset: const Offset(0, 1))],
              ),
              padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault, vertical: Dimensions.paddingSizeSmall),
              margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
              child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Image.asset(Images.cutlery, height: 18, width: 18, color: Theme.of(context).textTheme.bodyLarge!.color,),
                const SizedBox(width: Dimensions.paddingSizeDefault),

                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('add_cutlery'.tr, style: robotoMedium.copyWith(color: Theme.of(context).primaryColor)),
                    const SizedBox(height: Dimensions.paddingSizeExtraSmall),

                    Text('do_not_have_cutlery'.tr, style: robotoRegular.copyWith(color: Theme.of(context).disabledColor, fontSize: Dimensions.fontSizeSmall)),
                  ]),
                ),

                Transform.scale(
                  scale: 0.7,
                  child: CupertinoSwitch(
                    value: cartController.addCutlery,
                    activeTrackColor: Theme.of(context).primaryColor,
                    onChanged: (bool? value) {
                      cartController.updateCutlery();
                    },
                    inactiveTrackColor: Theme.of(context).primaryColor.withValues(alpha: 0.5),
                  ),
                ),

              ]),
            ) : const SizedBox(),

            isDesktop ? const SizedBox() : Container(
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 2, spreadRadius: 1, offset: const Offset(0, 1))],
                // border: Border.all(color: Theme.of(context).primaryColor, width: 0.5),
              ),
              padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
              margin: isDesktop ? const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault, vertical: Dimensions.paddingSizeSmall) : EdgeInsets.only(bottom: Dimensions.paddingSizeLarge),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  InkWell(
                    onTap: (){
                      if(isDesktop) {
                        Get.dialog(const Dialog(child: NotAvailableBottomSheetWidget()));
                      } else {
                        showModalBottomSheet(
                          context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                          builder: (con) => const NotAvailableBottomSheetWidget(),
                        );
                      }
                    },
                    child: Row(children: [
                      Expanded(child: Text('if_any_product_is_not_available'.tr, style: robotoMedium, maxLines: 2, overflow: TextOverflow.ellipsis)),
                      const Icon(Icons.keyboard_arrow_down_rounded, size: 18),
                    ]),
                  ),

                  cartController.notAvailableIndex != -1 ? Row(children: [
                    Text(cartController.notAvailableList[cartController.notAvailableIndex].tr, style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).primaryColor)),

                    IconButton(
                      onPressed: ()=> cartController.setAvailableIndex(-1),
                      icon: const Icon(Icons.clear, size: 18),
                    )
                  ]) : const SizedBox(),
                ],
              ),
            ),
            isDesktop ? const SizedBox() : const SizedBox(height: Dimensions.paddingSizeSmall),

            // Total
            isDesktop ? Padding(
              padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault, vertical: Dimensions.paddingSizeSmall),
              child: Column(children: [
                // Merge "Item Price" and "Variations" into a single line so the
                // user only sees one "item_price" row that already includes the
                // chosen variation options. See the mobile pricing view for the
                // full explanation.
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('item_price'.tr, style: robotoRegular),
                  PriceConverter.convertAnimationPrice(
                    (Get.find<SplashController>().getModuleConfig(item.moduleType).newVariation! &&
                            cartController.variationPrice > 0)
                        ? cartController.itemPrice + cartController.variationPrice
                        : cartController.itemPrice,
                    textStyle: robotoRegular,
                  ),
                ]),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('discount'.tr, style: robotoRegular),
                  storeController.store != null ? Row(children: [
                    Text('(-)', style: robotoRegular),
                    PriceConverter.convertAnimationPrice(cartController.itemDiscountPrice, textStyle: robotoRegular),
                  ]) : Text('calculating'.tr, style: robotoRegular),
                  // Text('(-) ${PriceConverter.convertPrice(cartController.itemDiscountPrice)}', style: robotoRegular, textDirection: TextDirection.ltr),
                ]),
                SizedBox(height: Get.find<SplashController>().configModel!.moduleConfig!.module!.addOn! ? 10 : 0),

                Get.find<SplashController>().configModel!.moduleConfig!.module!.addOn! ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('addons'.tr, style: robotoRegular),
                    Text('(+) ${PriceConverter.convertPrice(cartController.addOns)}', style: robotoRegular, textDirection: TextDirection.ltr),
                  ],
                ) : const SizedBox(),

                (storeController.store != null && storeController.store!.extraPackagingStatus! && cartController.needExtraPackage) ? Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('extra_packaging'.tr, style: robotoRegular),
                      Text('(+) ${PriceConverter.convertPrice(storeController.store!.extraPackagingAmount!)}', style: robotoRegular, textDirection: TextDirection.ltr),
                    ],
                  ),
                ) : const SizedBox.shrink(),
              ]),
            ) : const SizedBox(),

            isDesktop ? CheckoutButton(cartController: cartController, availableList: cartController.availableList) : const SizedBox.shrink(),

          ]);
        }
      ),
    );
  }

  Widget suggestedItemView(List<CartModel> cartList){
    bool isDesktop = ResponsiveHelper.isDesktop(context);
    return Container(
      decoration: BoxDecoration(color: Theme.of(context).cardColor),
      width: double.infinity,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        GetBuilder<StoreController>(builder: (storeController) {
          List<Item>? suggestedItems;
          if(storeController.cartSuggestItemModel != null){
            suggestedItems = [];
            List<int> cartIds = [];
            for (CartModel cartItem in cartList) {
              cartIds.add(cartItem.item!.id!);
            }
            for (Item item in storeController.cartSuggestItemModel!.items!) {
              if(!cartIds.contains(item.id)){
                suggestedItems.add(item);
              }
            }
          }
          return storeController.cartSuggestItemModel != null && suggestedItems!.isNotEmpty ? Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: Dimensions.paddingSizeSmall),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault, vertical: Dimensions.paddingSizeExtraSmall),
                child: Text('you_may_also_like'.tr, style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeDefault)),
              ),

              SizedBox(
                height: isDesktop ? 160 : 130,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: suggestedItems.length,
                  physics: const BouncingScrollPhysics(),
                  padding: EdgeInsets.only(left: isDesktop ? Dimensions.paddingSizeExtraSmall : Dimensions.paddingSizeDefault),
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: isDesktop ? const EdgeInsets.symmetric(vertical: 20) : const EdgeInsets.symmetric(vertical: 10) ,
                      child: Container(
                        width: isDesktop ? 500 : 300,
                        padding: const EdgeInsets.only(right: Dimensions.paddingSizeSmall, left: Dimensions.paddingSizeExtraSmall),
                        margin: const EdgeInsets.only(right: Dimensions.paddingSizeSmall),
                        child: ItemWidget(
                          isStore: false, item: suggestedItems![index], fromCartSuggestion: true,
                          store: null, index: index, length: null, isCampaign: false, inStore: true,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ) : const SizedBox();
        }),
      ]),
    );
  }

  Future<void> showReferAndEarnSnackBar() async {
    String text = 'your_referral_discount_added_on_your_first_order'.tr;
    if(Get.find<ProfileController>().userInfoModel != null &&  Get.find<ProfileController>().userInfoModel!.isValidForDiscount!) {
      showCustomSnackBar(text, isError: false);
    }
  }

}

class CheckoutButton extends StatelessWidget {
  final CartController cartController;
  final List<bool> availableList;
  const CheckoutButton({super.key, required this.cartController, required this.availableList});

  @override
  Widget build(BuildContext context) {
    double percentage = 0;
    bool isDesktop = ResponsiveHelper.isDesktop(context);

    return Container(
      width: Dimensions.webMaxWidth,
      padding:  const EdgeInsets.all(Dimensions.paddingSizeSmall),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(isDesktop ? Dimensions.radiusDefault : 0),
      ),
      child: GetBuilder<StoreController>(
        builder: (storeController) {
          if(Get.find<StoreController>().store != null && !Get.find<StoreController>().store!.freeDelivery!
            && (Get.find<SplashController>().configModel?.adminFreeDelivery?.status == true && (Get.find<SplashController>().configModel?.adminFreeDelivery?.type != null && Get.find<SplashController>().configModel?.adminFreeDelivery?.type == 'free_delivery_by_order_amount') && (Get.find<SplashController>().configModel!.adminFreeDelivery?.freeDeliveryOver != null))){
            percentage = cartController.subTotal/Get.find<SplashController>().configModel!.adminFreeDelivery!.freeDeliveryOver!;
          }
          double subTotal = cartController.subTotal;
          if(storeController.store != null && storeController.store!.extraPackagingStatus! && cartController.needExtraPackage) {
            subTotal = subTotal + storeController.store!.extraPackagingAmount!;
          }
            return Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              (!isDesktop && storeController.store != null && !storeController.store!.freeDelivery! && (Get.find<SplashController>().configModel?.adminFreeDelivery?.status == true && (Get.find<SplashController>().configModel?.adminFreeDelivery?.type != null && Get.find<SplashController>().configModel?.adminFreeDelivery?.type == 'free_delivery_by_order_amount') && (Get.find<SplashController>().configModel!.adminFreeDelivery?.freeDeliveryOver != null)) && percentage < 1)
              ? Column(children: [
                  Row(children: [
                    Image.asset(Images.percentTag, height: 20, width: 20, color: Colors.orange,),
                    const SizedBox(width: Dimensions.paddingSizeExtraSmall),

                    Text(
                      PriceConverter.convertPrice(Get.find<SplashController>().configModel!.adminFreeDelivery!.freeDeliveryOver! - cartController.subTotal),
                      style: robotoMedium.copyWith(color: Colors.orange), textDirection: TextDirection.ltr,
                    ),
                    const SizedBox(width: Dimensions.paddingSizeExtraSmall),

                    Text('more_for_free_delivery'.tr, style: robotoMedium.copyWith(color: Theme.of(context).disabledColor)),
                  ]),
                const SizedBox(height: Dimensions.paddingSizeExtraSmall),

                LinearProgressIndicator(
                  backgroundColor: Theme.of(context).disabledColor.withValues(alpha: 0.2),
                  value: percentage,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.orange),
                ),
              ]) : const SizedBox(),

              isDesktop ? const Divider(height: 1) : const SizedBox(),
              const SizedBox(height: Dimensions.paddingSizeExtraSmall),

              Padding(
                padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('subtotal'.tr, style: robotoMedium.copyWith(color: Theme.of(context).textTheme.bodyLarge!.color)),
                    PriceConverter.convertAnimationPrice(subTotal, textStyle: robotoBold.copyWith()),
                  ],
                ),
              ),

              isDesktop && Get.find<SplashController>().getModuleConfig(cartController.cartList[0].item!.moduleType).newVariation!
              && (storeController.store != null && storeController.store!.cutlery!) ? Padding(
                padding: const EdgeInsets.symmetric(horizontal: 0, vertical: Dimensions.paddingSizeSmall),
                child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                  Image.asset(Images.cutlery, height: 18, width: 18),
                  const SizedBox(width: Dimensions.paddingSizeDefault),

                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('add_cutlery'.tr, style: robotoMedium.copyWith(color: Theme.of(context).primaryColor)),
                      const SizedBox(height: Dimensions.paddingSizeExtraSmall),

                      Text('do_not_have_cutlery'.tr, style: robotoRegular.copyWith(color: Theme.of(context).disabledColor, fontSize: Dimensions.fontSizeSmall)),
                    ]),
                  ),

                  Transform.scale(
                    scale: 0.7,
                    child: CupertinoSwitch(
                      value: cartController.addCutlery,
                      activeTrackColor: Theme.of(context).primaryColor,
                      onChanged: (bool? value) {
                        cartController.updateCutlery();
                      },
                      inactiveTrackColor: Theme.of(context).primaryColor.withValues(alpha: 0.5),
                    ),
                  )
                ]),
              ) : const SizedBox(),
              isDesktop ? const SizedBox(height: Dimensions.paddingSizeSmall) : const SizedBox(),

              !isDesktop ? const SizedBox() :
              Container(
                width: Dimensions.webMaxWidth,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
                  color: Theme.of(context).cardColor,
                  border: Border.all(color: Theme.of(context).disabledColor.withValues(alpha: 0.2), width: 0.5),
                ),
                padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    InkWell(
                      onTap: (){
                        if(isDesktop) {
                          Get.dialog(const Dialog(child: NotAvailableBottomSheetWidget()));
                        } else {
                          showModalBottomSheet(
                            context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
                            builder: (con) => const NotAvailableBottomSheetWidget(),
                          );
                        }
                      },
                      child: Row(children: [
                        Expanded(child: Text('if_any_product_is_not_available'.tr, style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall), maxLines: 2, overflow: TextOverflow.ellipsis)),
                        const Icon(Icons.keyboard_arrow_down, size: 18),
                      ]),
                    ),
                    const SizedBox(height: Dimensions.paddingSizeExtraSmall),

                    Container(
                      padding: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
                        color: Theme.of(context).disabledColor.withValues(alpha: 0.1),
                      ),
                      child: cartController.notAvailableIndex != -1 ? Row(mainAxisSize: MainAxisSize.min,  children: [
                        Text(cartController.notAvailableList[cartController.notAvailableIndex].tr, style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).hintColor)),

                        IconButton(
                          onPressed: ()=> cartController.setAvailableIndex(-1),
                          icon: const Icon(Icons.clear, size: 18, color: Colors.red),
                        )
                      ]) : const SizedBox(),
                    ),
                  ],
                ),
              ),

              isDesktop && Get.find<SplashController>().getModuleConfig(cartController.cartList[0].item!.moduleType).newVariation! && storeController.store != null && storeController.store!.deliveryTime != null ? Container(
                decoration: BoxDecoration(
                  color: Colors.orange.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                ),
                width: double.infinity,
                padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                margin: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeDefault),
                child: Row(children: [
                  Image.asset(Images.carDelivery, height: 20, width: 20, color: Colors.orange),
                  const SizedBox(width: Dimensions.paddingSizeSmall),
                  RichText(text: TextSpan(children: [
                    TextSpan(text: '${'estimated_delivery_time'.tr} : ', style: robotoMedium.copyWith(color: Theme.of(context).textTheme.bodyLarge!.color!.withValues(alpha: 0.5))),
                    TextSpan(text: '${storeController.store?.deliveryTime}', style: robotoBold.copyWith(color: Theme.of(context).textTheme.bodyLarge!.color)),
                  ])),

                ]),
              ) : const SizedBox(),

              (isDesktop && storeController.store != null && !storeController.store!.freeDelivery! && (Get.find<SplashController>().configModel?.adminFreeDelivery?.status == true && (Get.find<SplashController>().configModel?.adminFreeDelivery?.type != null && Get.find<SplashController>().configModel?.adminFreeDelivery?.type == 'free_delivery_by_order_amount') && (Get.find<SplashController>().configModel!.adminFreeDelivery?.freeDeliveryOver != null)) && percentage < 1)
                  ? Column(children: [
                    const SizedBox(height: Dimensions.paddingSizeSmall),

                Row(children: [
                  Image.asset(Images.percentTag, height: 20, width: 20, color: Colors.orange,),
                  const SizedBox(width: Dimensions.paddingSizeExtraSmall),

                  Text(
                    PriceConverter.convertPrice(Get.find<SplashController>().configModel!.adminFreeDelivery!.freeDeliveryOver! - cartController.subTotal),
                    style: robotoMedium.copyWith(color: Colors.orange), textDirection: TextDirection.ltr,
                  ),
                  const SizedBox(width: Dimensions.paddingSizeExtraSmall),

                  Text('more_for_free_delivery'.tr, style: robotoMedium.copyWith(color: Theme.of(context).disabledColor)),
                ]),
                const SizedBox(height: Dimensions.paddingSizeExtraSmall),

                LinearProgressIndicator(
                  backgroundColor: Theme.of(context).disabledColor.withValues(alpha: 0.2),
                  value: percentage,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.orange),
                ),
              ]) : const SizedBox(),
              isDesktop ? const SizedBox(height: Dimensions.paddingSizeSmall) : const SizedBox(),

              SafeArea(
                child: CustomButton(
                  buttonText: 'confirm_delivery_details'.tr,
                  fontSize: isDesktop ? Dimensions.fontSizeSmall : Dimensions.fontSizeLarge,
                  isBold:  isDesktop ? false : true,
                  radius: isDesktop ? Dimensions.radiusSmall : Dimensions.radiusDefault,
                  onPressed: () async {
                    Get.find<CheckoutController>().updateFirstTime();
                    Get.find<CheckoutController>().updateFirstTimeCodActive();
                  if(!cartController.cartList.first.item!.scheduleOrder! && availableList.contains(false)) {
                    showCustomSnackBar('one_or_more_product_unavailable'.tr);
                  }else {
                    if(Get.find<SplashController>().module == null) {
                      await Get.find<SplashController>().getModules();
                      int i = 0;
                      for(i = 0; i < Get.find<SplashController>().moduleList!.length; i++){
                        if(cartController.cartList[0].item!.moduleId == Get.find<SplashController>().moduleList![i].id){
                          break;
                        }
                      }
                      Get.find<SplashController>().setModule(Get.find<SplashController>().moduleList![i]);
                      HomeScreen.loadData(true);
                    }
                    Get.find<CouponController>().removeCouponData(false);

                    Get.toNamed(RouteHelper.getCheckoutRoute('cart'));
                  }
                }),
              ),
            ],
          );
        }
      ),
    );
  }
}
