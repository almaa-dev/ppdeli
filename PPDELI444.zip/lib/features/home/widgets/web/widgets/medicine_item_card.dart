import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pickles_and_pies/common/widgets/custom_ink_well.dart';
import 'package:pickles_and_pies/common/widgets/hover/text_hover.dart';
import 'package:pickles_and_pies/features/item/controllers/item_controller.dart';
import 'package:pickles_and_pies/features/splash/controllers/splash_controller.dart';
import 'package:pickles_and_pies/features/item/domain/models/item_model.dart';
import 'package:pickles_and_pies/helper/price_converter.dart';
import 'package:pickles_and_pies/helper/responsive_helper.dart';
import 'package:pickles_and_pies/util/app_constants.dart';
import 'package:pickles_and_pies/util/dimensions.dart';
import 'package:pickles_and_pies/util/images.dart';
import 'package:pickles_and_pies/util/styles.dart';
import 'package:pickles_and_pies/common/widgets/add_favourite_view.dart';
import 'package:pickles_and_pies/common/widgets/cart_count_view.dart';
import 'package:pickles_and_pies/common/widgets/custom_image.dart';
import 'package:pickles_and_pies/common/widgets/discount_tag.dart';
import 'package:pickles_and_pies/common/widgets/hover/on_hover.dart';
import 'package:pickles_and_pies/common/widgets/organic_tag.dart';

class MedicineItemCard extends StatelessWidget {
  final Item item;
  final bool fromShop;
  const MedicineItemCard({super.key, required this.item, this.fromShop = false});

  @override
  Widget build(BuildContext context) {
    bool isShop = Get.find<SplashController>().module != null && Get.find<SplashController>().module!.moduleType.toString() == AppConstants.ecommerce;
    double? discount = item.discount;
    String? discountType = item.discountType;

    return OnHover(
      isItem: true,
      child: Container(
        width: ResponsiveHelper.isDesktop(context) ? 230 : isShop ? 200 : 180,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
          color: Theme.of(context).cardColor,
          boxShadow: [BoxShadow(color: Theme.of(context).disabledColor.withValues(alpha: 0.1), spreadRadius: 0, blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: CustomInkWell(
          onTap: () => Get.find<ItemController>().navigateToItemPage(item, context),
          radius: Dimensions.radiusDefault,
          child: TextHover(
            builder: (hovered) {
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                Expanded(
                  flex: 5,
                  child: Stack(children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(Dimensions.radiusDefault),
                        topRight: Radius.circular(Dimensions.radiusDefault),
                      ),
                      child: CustomImage(
                        isHovered: hovered,
                        placeholder: Images.placeholder,
                        image: '${item.imageFullUrl}',
                        fit: BoxFit.cover, width: double.infinity, height: double.infinity,
                      ),
                    ),

                    AddFavouriteView(item: item),

                    DiscountTag(
                      discount: discount,
                      discountType: discountType,
                      freeDelivery: false,
                    ),

                    OrganicTag(item: item, placeInImage: false),

                    isShop ? const SizedBox() : Positioned(
                      bottom: 10, right: 10,
                      child: CartCountView(
                        item: item,
                        child: Container(
                          height: 25, width: 25,
                          decoration: BoxDecoration(shape: BoxShape.circle, color: Theme.of(context).primaryColor),
                          child: Icon(Icons.add, size: 20, color: Theme.of(context).cardColor),
                        ),
                      ),
                    ),
                  ]),
                ),

                Expanded(
                  flex: 5,
                  child: Padding(
                    padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                    child: Column(
                      crossAxisAlignment: isShop ? CrossAxisAlignment.center : CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [

                      Row(
                        mainAxisAlignment: fromShop ? MainAxisAlignment.center : MainAxisAlignment.start,
                        children: [
                          Flexible(
                            child: Text(
                              item.storeName ?? '',
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: robotoRegular.copyWith(color: Theme.of(context).disabledColor, fontSize: Dimensions.fontSizeSmall),
                            ),
                          ),
                          const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                          item.verifiedSeller == 1 ? Image.asset(Images.verifiedBadge, width: 14, height: 14) : SizedBox.shrink(),
                        ],
                      ),

                      Text(item.name ?? '', style: robotoBold,
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                      ),

                      if(item.genericName != null && item.genericName!.isNotEmpty)
                        Wrap(
                          children: List.generate(item.genericName!.length, (index) {
                            return Text(
                              '${item.genericName![index]}${item.genericName!.length-1 == index ? '.' : ', '}',
                              style: robotoRegular.copyWith(color: Theme.of(context).textTheme.bodyLarge!.color?.withValues(alpha: 0.5), fontSize: Dimensions.fontSizeSmall),
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                            );
                          }),
                        ),

                      if(isShop)
                        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.star, size: 15, color: Colors.orange),
                          const SizedBox(width: Dimensions.paddingSizeExtraSmall),

                          Text(item.avgRating.toString(), style: robotoRegular),
                          const SizedBox(width: Dimensions.paddingSizeExtraSmall),

                          Text("(${item.ratingCount})", style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).disabledColor)),

                        ]),

                      item.discount != null && item.discount! > 0  ? Text(
                        PriceConverter.convertPrice(Get.find<ItemController>().getStartingPrice(item)),
                        style: robotoMedium.copyWith(
                          fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).disabledColor,
                          decoration: TextDecoration.lineThrough,
                        ), textDirection: TextDirection.ltr,
                      ) : const SizedBox(),

                      Align(
                        alignment: isShop ? Alignment.center : Alignment.centerLeft,
                        child: Row(mainAxisAlignment: isShop ? MainAxisAlignment.center : MainAxisAlignment.start, children: [
                          Text(
                            PriceConverter.convertPrice(
                              Get.find<ItemController>().getStartingPrice(item), discount: item.discount,
                              discountType: item.discountType,
                            ),
                            textDirection: TextDirection.ltr, style: robotoMedium,
                          ),
                          const SizedBox(width: Dimensions.paddingSizeExtraSmall),

                          (Get.find<SplashController>().configModel!.moduleConfig!.module!.unit! && item.unitType != null) ? Text(
                            '/ ${ item.unitType ?? ''}',
                            style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).hintColor),
                          ) : const SizedBox(),
                        ]),
                      ),
                    ],
                    ),
                  ),
                ),
              ],
              );
            }
          ),
        ),
      ),
    );
  }
}