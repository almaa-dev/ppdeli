import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pickles_and_pies/common/controllers/theme_controller.dart';
import 'package:pickles_and_pies/features/home/widgets/fast_order_button.dart';
import 'package:pickles_and_pies/features/home/widgets/highlight_widget.dart';
import 'package:pickles_and_pies/features/reels/widgets/reels_section_widget.dart';
import 'package:pickles_and_pies/features/home/widgets/views/all_products_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/category_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/recommended_store_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/top_offers_near_me.dart';
import 'package:pickles_and_pies/helper/auth_helper.dart';
import 'package:pickles_and_pies/util/images.dart';
import 'package:pickles_and_pies/features/home/widgets/views/best_reviewed_item_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/item_that_you_love_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/just_for_you_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/most_popular_item_view.dart';
// import 'package:pickles_and_pies/features/home/widgets/views/new_on_mart_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/visit_again_view.dart';
import 'package:pickles_and_pies/features/home/widgets/banner_view.dart';

class FoodHomeScreen extends StatelessWidget {
  const FoodHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    bool isLoggedIn = AuthHelper.isLoggedIn();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

      Container(
        width: MediaQuery.of(context).size.width,
        decoration: Get.find<ThemeController>().darkTheme ? null : const BoxDecoration(
          image: DecorationImage(
            image: AssetImage(Images.foodModuleBannerBg),
            fit: BoxFit.cover,
          ),
        ),
        child: const Column(
          children: [
            BannerView(isFeatured: false),
            SizedBox(height: 12),
          ],
        ),
      ),
      const FastOrderButton(),
      const CategoryView(),
      const ReelsSectionWidget(),
      isLoggedIn ? const VisitAgainView(fromFood: true) : const SizedBox(),
      const RecommendedStoreView(),
      const HighlightWidget(),
      const TopOffersNearMe(),
      const BestReviewItemView(),
      const ItemThatYouLoveView(forShop: false),
      const MostPopularItemView(isFood: true, isShop: false),
      const JustForYouView(),
      // const NewOnMartView(isNewStore: true, isPharmacy: false, isShop: false),
      const AllProductsView(),
    ]);
  }
}