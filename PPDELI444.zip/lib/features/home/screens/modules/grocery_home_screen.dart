import 'package:flutter/material.dart';
import 'package:pickles_and_pies/features/flash_sale/widgets/flash_sale_view_widget.dart';
import 'package:pickles_and_pies/features/home/widgets/fast_order_button.dart';
import 'package:pickles_and_pies/features/home/widgets/highlight_widget.dart';
import 'package:pickles_and_pies/features/reels/widgets/reels_section_widget.dart';
import 'package:pickles_and_pies/features/home/widgets/views/banner_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/best_reviewed_item_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/best_store_nearby_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/category_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/promo_code_banner_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/item_that_you_love_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/just_for_you_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/most_popular_item_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/new_on_mart_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/middle_section_banner_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/recommended_store_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/special_offer_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/promotional_banner_view.dart';
import 'package:pickles_and_pies/features/home/widgets/views/top_offers_near_me.dart';
import 'package:pickles_and_pies/features/home/widgets/views/visit_again_view.dart';
import 'package:pickles_and_pies/helper/auth_helper.dart';


class GroceryHomeScreen extends StatelessWidget {
  const GroceryHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    bool isLoggedIn = AuthHelper.isLoggedIn();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

      Container(
        width: MediaQuery.of(context).size.width,
        color: Theme.of(context).disabledColor.withValues(alpha: 0.1),
        child:  const Column(
          children: [
            BannerView(isFeatured: false),
            SizedBox(height: 12),
          ],
        ),
      ),
      const FastOrderButton(),
      const CategoryView(),
      const ReelsSectionWidget(),
      isLoggedIn ? const VisitAgainView() : const SizedBox(),
      const RecommendedStoreView(),
      const SpecialOfferView(isFood: false, isShop: false),
      const HighlightWidget(),
      const FlashSaleViewWidget(),
      const BestStoreNearbyView(),
      const MostPopularItemView(isFood: false, isShop: false),
      const MiddleSectionBannerView(),
      const BestReviewItemView(),
      const JustForYouView(),
      const TopOffersNearMe(),
      const ItemThatYouLoveView(forShop: false),
      isLoggedIn ? const PromoCodeBannerView() : const SizedBox(),
      const NewOnMartView(isPharmacy: false, isShop: false),
      const PromotionalBannerView(),
    ]);
  }
}
