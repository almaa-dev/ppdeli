import 'package:flutter/foundation.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:pickles_and_pies/common/widgets/address_widget.dart';
import 'package:pickles_and_pies/features/address/controllers/address_controller.dart';
import 'package:pickles_and_pies/features/cart/controllers/cart_controller.dart';
import 'package:pickles_and_pies/features/coupon/controllers/coupon_controller.dart';
import 'package:pickles_and_pies/features/home/controllers/home_controller.dart';
import 'package:pickles_and_pies/features/item/domain/models/item_model.dart';
import 'package:pickles_and_pies/features/splash/controllers/splash_controller.dart';
import 'package:pickles_and_pies/features/profile/controllers/profile_controller.dart';
import 'package:pickles_and_pies/features/checkout/domain/models/place_order_body_model.dart';
import 'package:pickles_and_pies/features/address/domain/models/address_model.dart';
import 'package:pickles_and_pies/features/cart/domain/models/cart_model.dart';
import 'package:pickles_and_pies/common/models/config_model.dart';
import 'package:pickles_and_pies/features/location/domain/models/zone_response_model.dart';
import 'package:pickles_and_pies/features/checkout/controllers/checkout_controller.dart';
import 'package:pickles_and_pies/features/store/domain/models/store_model.dart';
import 'package:pickles_and_pies/helper/address_helper.dart';
import 'package:pickles_and_pies/helper/auth_helper.dart';
import 'package:pickles_and_pies/helper/custom_validator.dart';
import 'package:pickles_and_pies/helper/date_converter.dart';
import 'package:pickles_and_pies/helper/price_converter.dart';
import 'package:pickles_and_pies/helper/responsive_helper.dart';
import 'package:pickles_and_pies/helper/route_helper.dart';
import 'package:pickles_and_pies/helper/shallow_route_helper.dart';
import 'package:pickles_and_pies/util/app_constants.dart';
import 'package:pickles_and_pies/util/dimensions.dart';
import 'package:pickles_and_pies/util/styles.dart';
import 'package:pickles_and_pies/common/widgets/custom_app_bar.dart';
import 'package:pickles_and_pies/common/widgets/custom_button.dart';
import 'package:pickles_and_pies/common/widgets/custom_dropdown.dart';
import 'package:pickles_and_pies/common/widgets/custom_snackbar.dart';
import 'package:pickles_and_pies/common/widgets/footer_view.dart';
import 'package:pickles_and_pies/common/widgets/menu_drawer.dart';
import 'package:pickles_and_pies/common/widgets/not_logged_in_screen.dart';
import 'package:pickles_and_pies/features/checkout/widgets/checkout_screen_shimmer_view.dart';
import 'package:pickles_and_pies/features/checkout/widgets/payment_method_bottom_sheet.dart';
import 'package:get/get.dart';
import 'package:pickles_and_pies/features/checkout/widgets/confirm_payment_method_dialog.dart';
import 'package:pickles_and_pies/features/checkout/widgets/bottom_section.dart';
import 'package:pickles_and_pies/features/checkout/widgets/top_section.dart';
import 'package:flutter/material.dart';
import 'package:pickles_and_pies/features/checkout/domain/helpers/delivery_fee_resolver.dart';

class CheckoutScreen extends StatefulWidget {
  final List<CartModel?>? cartList;
  final bool fromCart;
  final int? storeId;
  const CheckoutScreen({super.key, required this.fromCart, required this.cartList, required this.storeId});

  @override
  CheckoutScreenState createState() => CheckoutScreenState();
}

class CheckoutScreenState extends State<CheckoutScreen> {

  final ScrollController _scrollController = ScrollController();
  final JustTheController tooltipController1 = JustTheController();
  final JustTheController tooltipController2 = JustTheController();
  final JustTheController tooltipController3 = JustTheController();

  /// Single source of truth for the delivery-fee business rule.
  ///
  /// All checkout screens share the same resolver instance because the
  /// business rule itself is stateless; it only depends on the values
  /// passed in by the caller.
  final DeliveryFeeResolver _deliveryFeeResolver = DeliveryFeeResolver();

  double? _taxPercent = 0;
  bool? _isCashOnDeliveryActive = false;
  bool? _isDigitalPaymentActive = false;
  bool _isOfflinePaymentActive = false;
  List<CartModel?>? _cartList;
  bool _isWalletActive = false;
  String _deliveryChargeForView = '';

  List<AddressModel> address = [];
  bool canCheckSmall = false;
  bool _isCashBackSnackBarShown = false;
  double badWeatherChargeForToolTip = 0;
  double extraChargeForToolTip = 0;
  bool isPassedVariationPrice = false;

  final TextEditingController guestContactPersonNameController = TextEditingController();
  final TextEditingController guestContactPersonNumberController = TextEditingController();
  final TextEditingController guestEmailController = TextEditingController();
  final TextEditingController guestPasswordController = TextEditingController();
  final TextEditingController guestConfirmPasswordController = TextEditingController();
  final FocusNode guestNumberNode = FocusNode();
  final FocusNode guestEmailNode = FocusNode();
  final FocusNode guestPasswordNode = FocusNode();
  final FocusNode guestConfirmPasswordNode = FocusNode();

  bool _isTaxCalled = false;
  double? _lastCouponDiscount;
  bool _firstTimeCheckPayment = false;

  @override
  void initState() {
    super.initState();

    // Schedule the call for the next microtask
    Future.microtask(() {
      initCall();
    });
  }

  Future<void> initCall() async {


    bool isLoggedIn = AuthHelper.isLoggedIn();
    Get.find<CheckoutController>().resetOrderTax();
    Get.find<CheckoutController>().initAdditionData();
    Get.find<CheckoutController>().couponController.text = '';

    Get.find<CheckoutController>().clearPrevData();
    Get.find<CheckoutController>().getDmTipMostTapped();
    Get.find<CheckoutController>().setPreferenceTimeForView('', isUpdate: false);
    Get.find<CheckoutController>().setExchangeAmount(0);

    Get.find<CheckoutController>().getOfflineMethodList();

    if(Get.find<CheckoutController>().isCreateAccount) {
      Get.find<CheckoutController>().toggleCreateAccount(willUpdate: false);
    }

    if(Get.find<CheckoutController>().isPartialPay){
      Get.find<CheckoutController>().changePartialPayment(isUpdate: false);
    }

    if(isLoggedIn) {
      // if(!GetPlatform.isWeb) {
        Get.find<CheckoutController>().insertAddresses(AddressHelper.getUserAddressFromSharedPref()!, notify: false);
      // }
      // Clear house and floor fields to start empty on each checkout
      Get.find<CheckoutController>().houseController.clear();
      Get.find<CheckoutController>().floorController.clear();
      if(Get.find<ProfileController>().userInfoModel == null) {
        Get.find<ProfileController>().getUserInfo().then((v) {
          if(Get.find<ProfileController>().userInfoModel != null && GetPlatform.isWeb) {
            Get.find<CheckoutController>().insertAddresses(AddressHelper.getUserAddressFromSharedPref()!, notify: false);
          }
        });
      }

      Get.find<CouponController>().getCouponList();

      if(Get.find<AddressController>().addressList == null) {
        Get.find<AddressController>().getAddressList();
      }
    } else {
      Get.find<CheckoutController>().setGuestAddress(AddressHelper.getUserAddressFromSharedPref(), isUpdate: false);
    }

    if(widget.storeId == null){
      _cartList = [];
      if(GetPlatform.isWeb) {
       await Get.find<CartController>().getCartDataOnline();
      }
      widget.fromCart ? _cartList!.addAll(Get.find<CartController>().cartList) : _cartList!.addAll(widget.cartList!);
      if(_cartList != null && _cartList!.isNotEmpty) {
        Get.find<CheckoutController>().initCheckoutData(_cartList![0]!.item!.storeId);
      }
    }
    if(widget.storeId != null){
      Get.find<CheckoutController>().initCheckoutData(widget.storeId);
      Get.find<CouponController>().removeCouponData(false);
    }
    Get.find<CheckoutController>().pickPrescriptionImage(isRemove: true, isCamera: false);
    _isWalletActive = Get.find<SplashController>().configModel!.customerWalletStatus == 1;
    Get.find<CheckoutController>().updateTips(
      Get.find<CheckoutController>().getSharedPrefDmTipIndex().isNotEmpty ? int.parse(Get.find<CheckoutController>().getSharedPrefDmTipIndex()) : 0,
      notify: false,
    );
    Get.find<CheckoutController>().tipController.text = Get.find<CheckoutController>().selectedTips != -1 ? AppConstants.tips[Get.find<CheckoutController>().selectedTips] : '';
  }

  void _setSinglePaymentActive() {
    if((!_firstTimeCheckPayment && !_isCashOnDeliveryActive! && _isDigitalPaymentActive! && Get.find<SplashController>().configModel!.activePaymentMethodList!.length == 1) && ((!_isWalletActive && AuthHelper.isLoggedIn()) || !AuthHelper.isLoggedIn()) ) {
      Future.delayed(const Duration(milliseconds: 600), (){
        if (!mounted) return;
        Get.find<CheckoutController>().setPaymentMethod(2, isUpdate: false);
        Get.find<CheckoutController>().changeDigitalPaymentName(Get.find<SplashController>().configModel!.activePaymentMethodList![0].getWay!, willUpdate: false);
        _firstTimeCheckPayment = true;
      });
    }
  }

  @override
  void dispose() {
    super.dispose();

    guestContactPersonNameController.dispose();
    guestContactPersonNumberController.dispose();
  }


  @override
  Widget build(BuildContext context) {

    Module? module = Get.find<SplashController>().configModel!.moduleConfig!.module;
    bool guestCheckoutPermission = AuthHelper.isGuestLoggedIn() && Get.find<SplashController>().configModel!.guestCheckoutStatus!;
    bool isLoggedIn = AuthHelper.isLoggedIn();
    bool isGuestLogIn = AuthHelper.isGuestLoggedIn();

    Future.delayed(const Duration(milliseconds: 100), () {
      if(AddressHelper.getUserAddressFromSharedPref() == null && GetPlatform.isWeb) {
        Get.find<SplashController>().setModule(null);
        ShallowRouterHelper.updateParameter('module', '');
        Future.delayed(const Duration(milliseconds: 10), () {
          Get.offAllNamed(RouteHelper.getInitialRoute(moduleId: 'null'));
        });
      }
    });

    return Scaffold(
      appBar: CustomAppBar(title: 'checkout'.tr),
      endDrawer: const MenuDrawer(),endDrawerEnableOpenDragGesture: false,
      body: guestCheckoutPermission || AuthHelper.isLoggedIn() ? GetBuilder<CheckoutController>(builder: (checkoutController) {

        List<DropdownItem<int>> addressList = _getDropdownAddressList(context: context, addressList: Get.find<AddressController>().addressList, store: checkoutController.store);
        address = _getAddressList(addressList: Get.find<AddressController>().addressList, store: checkoutController.store);

        bool todayClosed = false;
        bool tomorrowClosed = false;
        Pivot? moduleData = _getModuleData(store: checkoutController.store);
        _isCashOnDeliveryActive = _checkCODActive(store: checkoutController.store);
        _isDigitalPaymentActive = _checkDigitalPaymentActive(store: checkoutController.store);
        _isOfflinePaymentActive = Get.find<SplashController>().configModel!.offlinePaymentStatus! && _checkZoneOfflinePaymentOnOff(addressModel: AddressHelper.getUserAddressFromSharedPref(), checkoutController: checkoutController);
        if (kDebugMode) {
          print('====> COD : $_isCashOnDeliveryActive, Digital : $_isDigitalPaymentActive, Offline : $_isOfflinePaymentActive');
        }

        if(checkoutController.isFirstTimeCodActive && (_isCashOnDeliveryActive ?? false)){
          Future.delayed(Duration.zero, () => checkoutController.setPaymentMethod(0));
        }

        if(checkoutController.store != null) {
          todayClosed = checkoutController.isStoreClosed(true, checkoutController.store!.active!, checkoutController.store!.schedules);
          tomorrowClosed = checkoutController.isStoreClosed(false, checkoutController.store!.active!, checkoutController.store!.schedules);
          _taxPercent = checkoutController.store!.tax;
        }
        return GetBuilder<CouponController>(builder: (couponController) {
          double? maxCodOrderAmount;

          if(moduleData != null) {
            maxCodOrderAmount = moduleData.maximumCodOrderAmount;
          }
          double price = _calculatePrice(store: checkoutController.store, cartList: _cartList);
          double addOns = _calculateAddonsPrice(store: checkoutController.store, cartList: _cartList);
          double variations = _calculateVariationPrice(store: checkoutController.store, cartList: _cartList, calculateWithoutDiscount: true);
          double? itemDiscountPrice = _calculateDiscountPrice(store: checkoutController.store, cartList: _cartList, price: price, addOns: addOns, calStoreDiscount: false);
          double? storeDiscountPrice = _calculateDiscountPrice(store: checkoutController.store, cartList: _cartList, price: price, addOns: addOns, calStoreDiscount: true);

          double extraDiscount = _getExtraDiscountPrice(storeDiscountPrice, itemDiscountPrice);
          double? discount = _getDiscountPrice(storeDiscountPrice, itemDiscountPrice);
          double couponDiscount = PriceConverter.toFixed(couponController.discount!);

          if (kDebugMode) {
            print('========coupon discount: $couponDiscount');
          }

          double subTotal = _calculateSubTotal(price: price, addOns: addOns, variations: variations, cartList: _cartList);

          double referralDiscount = _calculateReferralDiscount(subTotal, discount, couponDiscount);

          double orderAmount = _calculateOrderAmount(
            price: price, variations: variations, discount: discount, addOns: addOns,
            couponDiscount: couponDiscount, cartList: _cartList, referralDiscount: referralDiscount,
          );

          if(_lastCouponDiscount != couponController.discount) {
            _isTaxCalled = false;
            _lastCouponDiscount = couponController.discount;
          }

          if(!_isTaxCalled && ((widget.storeId == null && checkoutController.store != null) || widget.storeId != null)) {
            _isTaxCalled = true;

            Future.delayed(const Duration(milliseconds: 50), () {
              List<OnlineCart> carts = [];

              if(widget.storeId == null && _cartList != null) {
                for (int index = 0; index < _cartList!.length; index++) {
                  CartModel cart = _cartList![index]!;
                  List<int?> addOnIdList = [];
                  List<int?> addOnQtyList = [];
                  for (var addOn in cart.addOnIds!) {
                    addOnIdList.add(addOn.id);
                    addOnQtyList.add(addOn.quantity);
                  }

                  List<OrderVariation> variations = [];
                  if(Get.find<SplashController>().getModuleConfig(cart.item!.moduleType).newVariation!) {
                    for(int i=0; i<cart.item!.foodVariations!.length; i++) {
                      if(cart.foodVariations![i].contains(true)) {
                        variations.add(OrderVariation(name: cart.item!.foodVariations![i].name, values: OrderVariationValue(label: [])));
                        for(int j=0; j<cart.item!.foodVariations![i].variationValues!.length; j++) {
                          if(cart.foodVariations![i][j]!) {
                            variations[variations.length-1].values!.label!.add(cart.item!.foodVariations![i].variationValues![j].level);
                          }
                        }
                      }
                    }
                  }
                  carts.add(OnlineCart(
                    cart.id, cart.item!.id, cart.isCampaign! ? cart.item!.id : null,
                    cart.discountedPrice.toString(), '',
                    Get.find<SplashController>().getModuleConfig(cart.item!.moduleType).newVariation! ? null : cart.variation,
                    Get.find<SplashController>().getModuleConfig(cart.item!.moduleType).newVariation! ? variations : null,
                    cart.quantity, addOnIdList, cart.addOns, addOnQtyList, 'Item', itemType: !widget.fromCart ? "AppModelsItemCampaign" : null,
                    note: cart.note,
                  ));
                }
              }

              PlaceOrderBodyModel placeOrderBody = PlaceOrderBodyModel(
                cart: carts, couponDiscountAmount: Get.find<CouponController>().discount, distance: checkoutController.distance,
                orderAmount: widget.storeId == null ? subTotal : 0, orderNote: checkoutController.noteController.text, orderType: checkoutController.orderType,
                  paymentMethod: checkoutController.paymentMethodIndex == 0 ? 'cash_on_delivery'
                      : checkoutController.paymentMethodIndex == 1 ? 'wallet'
                      : checkoutController.paymentMethodIndex == 2 ? 'digital_payment' : 'offline_payment',
                  couponCode: (Get.find<CouponController>().discount! > 0 || (Get.find<CouponController>().coupon != null
                      && Get.find<CouponController>().freeDelivery)) ? Get.find<CouponController>().coupon!.code : null,
                  storeId: (widget.storeId == null) ? _cartList![0]!.item!.storeId : widget.storeId,
                  discountAmount: discount, receiverDetails: null, parcelCategoryId: null,
                  chargePayer: null, dmTips: (checkoutController.orderType == 'take_away' || checkoutController.tipController.text == 'not_now') ? '' : checkoutController.tipController.text.trim(),
                  cutlery: Get.find<CartController>().addCutlery ? 1 : 0,
                  unavailableItemNote: Get.find<CartController>().notAvailableIndex != -1 ? Get.find<CartController>().notAvailableList[Get.find<CartController>().notAvailableIndex] : '',
                  deliveryInstruction: checkoutController.selectedInstruction != -1 ? AppConstants.deliveryInstructionList[checkoutController.selectedInstruction] : '',
                  partialPayment: checkoutController.isPartialPay ? 1 : 0, guestId: isGuestLogIn ? int.parse(AuthHelper.getGuestId()) : 0,
                  isBuyNow: widget.fromCart ? 0 : 1,
                  extraPackagingAmount: Get.find<CartController>().needExtraPackage ? checkoutController.store!.extraPackagingAmount : 0,
                  createNewUser: checkoutController.isCreateAccount ? 1 : 0, password: guestPasswordController.text,
                  isPrescriptionOrder: widget.storeId == null ? false : true,
                );

              if((widget.storeId == null && _cartList != null && _cartList!.isNotEmpty && placeOrderBody.storeId != null) || (widget.storeId != null)) {
                if (kDebugMode) {
                  print("=======store id: ${placeOrderBody.storeId}");
                }
                checkoutController.getOrderTax(placeOrderBody);
              }
            });
          }

          double additionalCharge =  Get.find<SplashController>().configModel!.additionalChargeStatus!
              ? Get.find<SplashController>().configModel!.additionCharge! : 0;
          double originalCharge = _calculateOriginalDeliveryCharge(
            store: checkoutController.store, address: AddressHelper.getUserAddressFromSharedPref()!,
            distance: checkoutController.distance, extraCharge: checkoutController.extraCharge,
            surgePrice: checkoutController.surgePrice?.price, surgePriceType: checkoutController.surgePrice?.priceType,
          );

          // Delegate the final delivery-fee decision to DeliveryFeeResolver.
          //
          // The resolver has three explicit outcomes (loading / free / paid),
          // so the UI can never accidentally treat a "not yet calculated"
          // -1 sentinel as Free. This is the root cause fix for the
          // legacy "Free -> $5 -> Free" flicker.
          final DeliveryFeeSnapshot feeSnapshot = _deliveryFeeResolver.resolve(
            orderType: checkoutController.orderType,
            orderAmount: orderAmount,
            store: checkoutController.store,
            distanceKm: checkoutController.distance,
            originalCharge: originalCharge,
            guestAddress: checkoutController.guestAddress,
            couponController: couponController,
          );

          double deliveryCharge;
          if (feeSnapshot.isLoading) {
            // Keep -1.0 as the in-band "calculating" sentinel that the
            // bottom_section widget already understands. The UI shows
            // "calculating" / "—" instead of "Free" until the snapshot
            // becomes free or paid.
            deliveryCharge = -1.0;
          } else {
            deliveryCharge = feeSnapshot.value;
          }

          // Pre-format the displayed string so it is stable for the whole
          // build. We rebuild only after a state change, never between
          // loading and a calculated value.
          String nextDeliveryChargeForView;
          if (checkoutController.orderType == 'take_away') {
            nextDeliveryChargeForView = 'free'.tr;
          } else if (feeSnapshot.isLoading) {
            nextDeliveryChargeForView = 'calculating'.tr;
          } else if (feeSnapshot.isFree) {
            nextDeliveryChargeForView = 'free'.tr;
          } else {
            nextDeliveryChargeForView = PriceConverter.convertPrice(deliveryCharge);
          }
          if (nextDeliveryChargeForView != _deliveryChargeForView) {
            // State variable is local to this widget. Schedule a rebuild
            // AFTER the current frame so TopSection / DeliveryOptionButton
            // pick up the new value on the next rebuild triggered by
            // CheckoutController.update().
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (!mounted) return;
              setState(() {
                _deliveryChargeForView = nextDeliveryChargeForView;
              });
            });
          }

          double extraPackagingCharge = widget.storeId != null ? 0 : _calculateExtraPackagingCharge(checkoutController);

          double total = _calculateTotal(
            subTotal: subTotal, deliveryCharge: deliveryCharge, discount: discount,
            couponDiscount: couponDiscount, taxIncluded: (checkoutController.taxIncluded == 1), tax: checkoutController.orderTax!, orderType: checkoutController.orderType!,
            tips: checkoutController.tips, additionalCharge: additionalCharge, extraPackagingCharge: extraPackagingCharge,
          );

          bool isPrescriptionRequired = _checkPrescriptionRequired();

          total = total - referralDiscount;

          if(widget.storeId != null){
            Future.delayed(Duration.zero, () => checkoutController.setPaymentMethod(0, isUpdate: false));
          }
          checkoutController.setTotalAmount(total - (checkoutController.isPartialPay ? Get.find<ProfileController>().userInfoModel!.walletBalance! : 0));

          if(!_isCashBackSnackBarShown && checkoutController.distance != null && checkoutController.distance != -1.0 && isLoggedIn && checkoutController.viewTotalPrice! > 0) {
            _isCashBackSnackBarShown = true;
            Future.delayed(const Duration(milliseconds: 800), () {
              showCashBackSnackBar(checkoutController.viewTotalPrice!);
            });
          }


          _setSinglePaymentActive();

          return (checkoutController.distance != null && checkoutController.store != null) ? Column(
            children: [
              ResponsiveHelper.isDesktop(context) ? Container(
                height: 64,
                color: Theme.of(context).primaryColor.withValues(alpha: 0.10),
                child: Center(child: Text('checkout'.tr, style: robotoMedium)),
              ) : const SizedBox(),

              Expanded(child: SingleChildScrollView(
                controller: _scrollController,
                physics: const BouncingScrollPhysics(),
                child: FooterView(child: SizedBox(
                  width: Dimensions.webMaxWidth,
                  child: ResponsiveHelper.isDesktop(context) ? Padding(
                    padding: const EdgeInsets.only(top: Dimensions.paddingSizeLarge),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [

                      Expanded(flex: 6, child: TopSection(
                        checkoutController: checkoutController, charge: originalCharge, deliveryCharge: deliveryCharge,
                        addressList: addressList,
                        tomorrowClosed: tomorrowClosed, todayClosed: todayClosed, module : module, price: price,
                        discount: discount, addOns: addOns, address: address, cartList: _cartList, isCashOnDeliveryActive: _isCashOnDeliveryActive!,
                        isDigitalPaymentActive: _isDigitalPaymentActive!, isWalletActive: _isWalletActive, storeId: widget.storeId,
                        total: total, isOfflinePaymentActive: _isOfflinePaymentActive, guestNameTextEditingController: guestContactPersonNameController,
                        guestNumberTextEditingController: guestContactPersonNumberController, guestNumberNode: guestNumberNode,
                        guestEmailController: guestEmailController, guestEmailNode: guestEmailNode,
                        tooltipController1: tooltipController1, tooltipController2: tooltipController2, dmTipsTooltipController: tooltipController3,
                        guestPasswordController: guestPasswordController, guestConfirmPasswordController: guestConfirmPasswordController,
                        guestPasswordNode: guestPasswordNode, guestConfirmPasswordNode: guestConfirmPasswordNode, variationPrice: isPassedVariationPrice ? variations : 0,
                        deliveryChargeForView: _deliveryChargeForView, badWeatherCharge: badWeatherChargeForToolTip, extraChargeForToolTip: extraChargeForToolTip,
                      )),
                      const SizedBox(width: Dimensions.paddingSizeLarge),

                      Expanded(flex: 4, child: BottomSection(
                        checkoutController: checkoutController, total: total, module: module!, subTotal: subTotal,
                        discount: discount, couponController: couponController, taxIncluded: (checkoutController.taxIncluded == 1), tax: checkoutController.orderTax!,
                        deliveryCharge: deliveryCharge,
                        todayClosed: todayClosed, tomorrowClosed: tomorrowClosed, orderAmount: orderAmount,
                        maxCodOrderAmount: maxCodOrderAmount, storeId: widget.storeId, taxPercent: _taxPercent, price: price, addOns : addOns,
                        isPrescriptionRequired: isPrescriptionRequired, checkoutButton: _orderPlaceButton(
                          checkoutController, todayClosed, tomorrowClosed, orderAmount,
                          deliveryCharge, checkoutController.orderTax!, discount, total, maxCodOrderAmount, isPrescriptionRequired,
                        ),
                        referralDiscount: referralDiscount, variationPrice: isPassedVariationPrice ? variations : 0, extraDiscount: extraDiscount, tooltipController1: tooltipController1, tooltipController2: tooltipController2,
                      )),
                    ]),
                  ) : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                    TopSection(
                      checkoutController: checkoutController, charge: originalCharge, deliveryCharge: deliveryCharge,
                      addressList: addressList,
                      tomorrowClosed: tomorrowClosed, todayClosed: todayClosed, module : module, price: price,
                      discount: discount, addOns: addOns, address: address, cartList: _cartList, isCashOnDeliveryActive: _isCashOnDeliveryActive!,
                      isDigitalPaymentActive: _isDigitalPaymentActive!, isWalletActive: _isWalletActive, storeId: widget.storeId,
                      total: total, isOfflinePaymentActive: _isOfflinePaymentActive, guestNameTextEditingController: guestContactPersonNameController,
                      guestNumberTextEditingController: guestContactPersonNumberController, guestNumberNode: guestNumberNode,
                      guestEmailController: guestEmailController, guestEmailNode: guestEmailNode,
                      tooltipController1: tooltipController1, tooltipController2: tooltipController2, dmTipsTooltipController: tooltipController3,
                      guestPasswordController: guestPasswordController, guestConfirmPasswordController: guestConfirmPasswordController,
                      guestPasswordNode: guestPasswordNode, guestConfirmPasswordNode: guestConfirmPasswordNode, variationPrice: isPassedVariationPrice ? variations : 0,
                      deliveryChargeForView: _deliveryChargeForView, badWeatherCharge: badWeatherChargeForToolTip, extraChargeForToolTip: extraChargeForToolTip,
                    ),

                    BottomSection(
                      checkoutController: checkoutController, total: total, module: module!, subTotal: subTotal,
                      discount: discount, couponController: couponController, taxIncluded: (checkoutController.taxIncluded == 1), tax: checkoutController.orderTax!,
                      deliveryCharge: deliveryCharge,
                      todayClosed: todayClosed,tomorrowClosed: tomorrowClosed, orderAmount: orderAmount,
                      maxCodOrderAmount: maxCodOrderAmount, storeId: widget.storeId, taxPercent: _taxPercent, price: price, addOns : addOns,
                      isPrescriptionRequired: isPrescriptionRequired, checkoutButton: _orderPlaceButton(
                        checkoutController, todayClosed, tomorrowClosed, orderAmount, deliveryCharge,
                      checkoutController.orderTax!, discount, total, maxCodOrderAmount, isPrescriptionRequired,
                      ),
                      referralDiscount: referralDiscount, variationPrice: isPassedVariationPrice ? variations : 0, extraDiscount: extraDiscount, tooltipController1: tooltipController1, tooltipController2: tooltipController2,
                    )
                  ]),
                )),
              )),

              ResponsiveHelper.isDesktop(context) ? const SizedBox() : Container(
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  boxShadow: [BoxShadow(color: Theme.of(context).primaryColor.withValues(alpha: 0.1), blurRadius: 10)],
                ),
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeLarge, vertical: Dimensions.paddingSizeExtraSmall),
                    child: Row(children: [
                      Text(
                        checkoutController.isPartialPay ? 'due_payment'.tr : 'total_amount'.tr,
                        style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeLarge, color: Theme.of(context).primaryColor),
                      ),

                      (checkoutController.taxIncluded == 1) ? Text(' ${'vat_tax_inc'.tr}', style: robotoMedium.copyWith(
                        fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).primaryColor,
                      )) : const SizedBox(),

                      const Expanded(child: SizedBox()),

                      PriceConverter.convertAnimationPrice(
                        checkoutController.viewTotalPrice,
                        textStyle: robotoMedium.copyWith(fontSize: Dimensions.fontSizeLarge, color: Theme.of(context).primaryColor),
                      ),
                    ]),
                  ),

                  _orderPlaceButton(checkoutController, todayClosed, tomorrowClosed, orderAmount, deliveryCharge, checkoutController.orderTax!, discount, total, maxCodOrderAmount, isPrescriptionRequired,
                  ),
                ]),
              ),

            ],
          ) : const CheckoutScreenShimmerView();
        });
      }) : NotLoggedInScreen(callBack: (value){
        initCall();
        setState(() {});
      }),
    );
  }


  Widget _orderPlaceButton(CheckoutController checkoutController, bool todayClosed, bool tomorrowClosed,
      double orderAmount, double? deliveryCharge, double tax, double? discount, double total, double? maxCodOrderAmount, bool isPrescriptionRequired) {
    return Container(
      width: Dimensions.webMaxWidth,
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall, horizontal: Dimensions.paddingSizeLarge),
      child: SafeArea(
        child: CustomButton(
          isLoading: checkoutController.isLoading,
          buttonText: 'place_order'.tr,
          onPressed: checkoutController.acceptTerms ? () async {
          bool isAvailable = true;
          DateTime scheduleStartDate = DateTime.now();
          DateTime scheduleEndDate = DateTime.now();
          bool isGuestLogIn = AuthHelper.isGuestLoggedIn();
          bool isDesktop = ResponsiveHelper.isDesktop(context);
          if(checkoutController.timeSlots == null || checkoutController.timeSlots!.isEmpty) {
            isAvailable = false;
          }else {
            DateTime date = checkoutController.selectedDateSlot == 0 ? DateTime.now() : DateTime.now().add(const Duration(days: 1));
            DateTime startTime = checkoutController.timeSlots![checkoutController.selectedTimeSlot].startTime!;
            DateTime endTime = checkoutController.timeSlots![checkoutController.selectedTimeSlot].endTime!;
            scheduleStartDate = DateTime(date.year, date.month, date.day, startTime.hour, startTime.minute+1);
            scheduleEndDate = DateTime(date.year, date.month, date.day, endTime.hour, endTime.minute+1);
            if(_cartList != null){
              for (CartModel? cart in _cartList!) {
                if (!DateConverter.isAvailable(
                  cart!.item!.availableTimeStarts, cart.item!.availableTimeEnds,
                  time: checkoutController.store!.scheduleOrder! ? scheduleStartDate : null,
                ) && !DateConverter.isAvailable(
                  cart.item!.availableTimeStarts, cart.item!.availableTimeEnds,
                  time: checkoutController.store!.scheduleOrder! ? scheduleEndDate : null,
                )) {
                  isAvailable = false;
                  break;
                }
              }
            }
          }

          bool isGuestValidNumber = false;
          if(isGuestLogIn && guestContactPersonNumberController.text.isNotEmpty) {
            String numberWithCountryCode = checkoutController.countryDialCode! + guestContactPersonNumberController.text;
            PhoneValid phoneValid = await CustomValidator.isPhoneValid(numberWithCountryCode);
            isGuestValidNumber = phoneValid.isValid;
          }
          bool isPhoneValid = false;
          if(AuthHelper.isLoggedIn()) {
            String numberWithCountryCode = checkoutController.countryDialCode! + checkoutController.contactPersonNumberController.text;
            PhoneValid phoneValid = await CustomValidator.isPhoneValid(numberWithCountryCode);
            isPhoneValid = phoneValid.isValid;
          }

          if(isGuestLogIn && guestContactPersonNameController.text.isEmpty) {
            showCustomSnackBar('please_enter_contact_person_name'.tr);
          } else if(isGuestLogIn && guestContactPersonNumberController.text.isEmpty) {
            showCustomSnackBar('please_enter_contact_person_number'.tr);
          } else if(isGuestLogIn && !isGuestValidNumber) {
            showCustomSnackBar('please_enter_valid_phone_number'.tr);
          } else if(isGuestLogIn && guestEmailController.text.isEmpty) {
            showCustomSnackBar('please_enter_contact_person_email'.tr);
          } else if(isGuestLogIn && checkoutController.contactPersonAddressController.text.isEmpty && checkoutController.orderType != 'take_away') {
            showCustomSnackBar('please_setup_your_delivery_address'.tr);
          }else if(isGuestLogIn && checkoutController.isCreateAccount && guestPasswordController.text.isEmpty) {
            showCustomSnackBar('enter_password'.tr);
          }else if(isGuestLogIn && checkoutController.isCreateAccount && guestConfirmPasswordController.text.isEmpty) {
            showCustomSnackBar('enter_confirm_password'.tr);
          }else if(isGuestLogIn && checkoutController.isCreateAccount && (guestPasswordController.text != guestConfirmPasswordController.text)) {
            showCustomSnackBar('confirm_password_does_not_matched'.tr);
          }else if(isPrescriptionRequired && checkoutController.pickedPrescriptions.isEmpty) {
            showCustomSnackBar('you_must_upload_prescription_for_this_order'.tr);
          }else if(AuthHelper.isLoggedIn() && !isDesktop && checkoutController.contactPersonNameController.text.isEmpty) {
            showCustomSnackBar('please_enter_contact_person_name'.tr);
          }else if(AuthHelper.isLoggedIn() && !isDesktop && checkoutController.contactPersonNumberController.text.isEmpty) {
            showCustomSnackBar('please_enter_contact_person_number'.tr);
          }else if(AuthHelper.isLoggedIn() && !isDesktop && checkoutController.contactPersonNumberController.text.isNotEmpty && !isPhoneValid) {
            showCustomSnackBar('please_enter_valid_phone_number'.tr);
          }else if(AuthHelper.isLoggedIn() && !isDesktop && checkoutController.contactPersonAddressController.text.isEmpty) {
            showCustomSnackBar('please_enter_contact_person_address'.tr);
          } else if(!_isCashOnDeliveryActive! && !_isDigitalPaymentActive! && !_isWalletActive && !_isOfflinePaymentActive) {
            showCustomSnackBar('no_payment_method_is_enabled'.tr);
          }else if(checkoutController.paymentMethodIndex == -1) {
            if(ResponsiveHelper.isDesktop(Get.context)){
              if(_isCashOnDeliveryActive! || _isDigitalPaymentActive! || _isWalletActive || _isOfflinePaymentActive){
                Get.dialog(Dialog(backgroundColor: Colors.transparent, child: PaymentMethodBottomSheet(
                  isCashOnDeliveryActive: _isCashOnDeliveryActive!, isDigitalPaymentActive: _isDigitalPaymentActive!,
                  totalPrice: total, isOfflinePaymentActive: _isOfflinePaymentActive,
                )));
              }else{
                showCustomSnackBar('no_payment_method_found'.tr);
              }
            }else{
              if(_isCashOnDeliveryActive! || _isDigitalPaymentActive! || _isWalletActive || _isOfflinePaymentActive){
                Get.bottomSheet(
                  PaymentMethodBottomSheet(
                    isCashOnDeliveryActive: _isCashOnDeliveryActive!, isDigitalPaymentActive: _isDigitalPaymentActive!,
                    totalPrice: total, isOfflinePaymentActive: _isOfflinePaymentActive,
                  ),
                  backgroundColor: Colors.transparent, isScrollControlled: true, useRootNavigator: true,
                );
              }else{
                showCustomSnackBar('no_payment_method_found'.tr);
              }
            }
          } else if(orderAmount < checkoutController.store!.minimumOrder! && widget.storeId == null) {
            showCustomSnackBar('${'minimum_order_amount_is'.tr} ${checkoutController.store!.minimumOrder}');
          }else if(checkoutController.tipController.text.isNotEmpty && checkoutController.tipController.text != 'not_now' && double.parse(checkoutController.tipController.text.trim()) < 0) {
            showCustomSnackBar('tips_can_not_be_negative'.tr);
          }else if((checkoutController.selectedDateSlot == 0 && todayClosed) || (checkoutController.selectedDateSlot == 1 && tomorrowClosed)) {
            showCustomSnackBar(Get.find<SplashController>().configModel!.moduleConfig!.module!.showRestaurantText!
                ? 'restaurant_is_closed'.tr : 'store_is_closed'.tr);
          }else if(checkoutController.paymentMethodIndex == 0 && _isCashOnDeliveryActive! && maxCodOrderAmount != null && maxCodOrderAmount != 0 && (total > maxCodOrderAmount) && widget.storeId == null){
            showCustomSnackBar('${'you_cant_order_more_then'.tr} ${PriceConverter.convertPrice(maxCodOrderAmount)} ${'in_cash_on_delivery'.tr}');
          }else if(checkoutController.paymentMethodIndex != 0 && widget.storeId != null){
            showCustomSnackBar('payment_method_is_not_available'.tr);
          }else if (checkoutController.timeSlots == null || checkoutController.timeSlots!.isEmpty) {
            if(checkoutController.store!.scheduleOrder!) {
              showCustomSnackBar('select_a_time'.tr);
            }else {
              showCustomSnackBar(Get.find<SplashController>().configModel!.moduleConfig!.module!.showRestaurantText!
                  ? 'restaurant_is_closed'.tr : 'store_is_closed'.tr);
            }
          }else if (!isAvailable) {
            showCustomSnackBar('one_or_more_products_are_not_available_for_this_selected_time'.tr);
          }else if (checkoutController.orderType != 'take_away' && checkoutController.distance == -1 && deliveryCharge == -1) {
            showCustomSnackBar('delivery_fee_not_set_yet'.tr);
          }else if (widget.storeId != null && checkoutController.pickedPrescriptions.isEmpty) {
            showCustomSnackBar('please_upload_your_prescription_images'.tr);
          }else if (!checkoutController.acceptTerms) {
            showCustomSnackBar('please_accept_privacy_policy_trams_conditions_refund_policy_first'.tr);
          }
          else if(checkoutController.paymentMethodIndex != -1 && !checkoutController.paymentMethodConfirmed){
            // PAYMENT CONFIRMATION GATE
            // ---------------------------------------------------------------
            // The user has a payment method pre-selected (either manually or
            // auto-restored from the last saved preference) but has NOT yet
            // confirmed it for THIS specific order. We must NOT skip ahead
            // and submit placeOrder() — the rules of this project require
            // explicit confirmation for every new order.
            //
            // Any async configuration change that invalidates the selection
            // would have already invalidated the confirmation through
            // CheckoutController.invalidatePaymentMethodConfirmation().
            // ---------------------------------------------------------------
            _showPaymentConfirmationDialog(
              onConfirm: _proceedWithPlaceOrder,
              onChange: _reopenPaymentMethodSelector,
            );
          }
          else {
            _runOrderSubmission();
          }
        } : null),
      ),
    );
  }

  // ===========================================================================
  // PAYMENT CONFIRMATION GATE — helpers
  // ===========================================================================
  // These helpers encapsulate the confirmation flow. They are intentionally
  // kept small and side-effect-free so the main Place-Order branch above stays
  // readable. The ONLY path that triggers the actual placeOrder() /
  // placePrescriptionOrder() is through _proceedWithPlaceOrder(), which is
  // only invoked from the dialog's Confirm callback (or after the user has
  // already confirmed earlier in the same build).
  // ===========================================================================

  /// Performs the actual order submission. Extracted from the Place-Order
  /// button so the confirmation dialog's Confirm callback can call it after
  /// setting the confirmation flag. Mirrors the original inline code.
  void _runOrderSubmission() {
    CheckoutController checkoutController = Get.find<CheckoutController>();
    bool isGuestLogIn = AuthHelper.isGuestLoggedIn();
    double total = checkoutController.viewTotalPrice ?? 0.0;
    double discount = 0;
    double tax = checkoutController.orderTax ?? 0;
    double? maxCodOrderAmount;
    try {
      maxCodOrderAmount = checkoutController.store?.minimumOrder;
    } catch (_) {}

    AddressModel? finalAddress =
        isGuestLogIn ? checkoutController.guestAddress : checkoutController.address;

    if (isGuestLogIn && checkoutController.orderType == 'take_away') {
      String number = checkoutController.countryDialCode! + guestContactPersonNumberController.text;
      finalAddress = AddressModel(
        contactPersonName: guestContactPersonNameController.text,
        contactPersonNumber: number,
        address: AddressHelper.getUserAddressFromSharedPref()!.address!,
        latitude: AddressHelper.getUserAddressFromSharedPref()!.latitude,
        longitude: AddressHelper.getUserAddressFromSharedPref()!.longitude,
        zoneId: AddressHelper.getUserAddressFromSharedPref()!.zoneId,
        email: guestEmailController.text,
      );
    } else if (isGuestLogIn && checkoutController.orderType != 'take_away') {
      String number = checkoutController.countryDialCode! + guestContactPersonNumberController.text;
      finalAddress = AddressModel(
        contactPersonName: guestContactPersonNameController.text,
        contactPersonNumber: number,
        address: checkoutController.contactPersonAddressController.text,
        latitude: checkoutController.guestAddress!.latitude,
        longitude: checkoutController.guestAddress!.longitude,
        zoneId: checkoutController.guestAddress!.zoneId,
        email: guestEmailController.text,
      );
    }

    if (!isGuestLogIn && finalAddress!.contactPersonNumber == 'null') {
      finalAddress.contactPersonNumber = Get.find<ProfileController>().userInfoModel!.phone;
    }

    if (AuthHelper.isLoggedIn()) {
      finalAddress?.contactPersonName = checkoutController.contactPersonNameController.text;
      finalAddress?.contactPersonNumber =
          checkoutController.countryDialCode! + checkoutController.contactPersonNumberController.text;
      finalAddress?.streetNumber = checkoutController.streetNumberController.text;
      finalAddress?.house = checkoutController.houseController.text;
      finalAddress?.floor = checkoutController.floorController.text;
    }

    if (widget.storeId == null) {
      _submitNormalOrder(
        checkoutController: checkoutController,
        finalAddress: finalAddress,
        total: total,
        tax: tax,
        discount: discount,
        maxCodOrderAmount: maxCodOrderAmount,
        isGuestLogIn: isGuestLogIn,
      );
    } else {
      _submitPrescriptionOrder(
        checkoutController: checkoutController,
        finalAddress: finalAddress,
        isGuestLogIn: isGuestLogIn,
      );
    }
  }

  /// Builds the cart payload and calls CheckoutController.placeOrder().
  /// Identical to the original inline code.
  void _submitNormalOrder({
    required CheckoutController checkoutController,
    required AddressModel? finalAddress,
    required double total,
    required double tax,
    required double discount,
    required double? maxCodOrderAmount,
    required bool isGuestLogIn,
  }) {
    List<OnlineCart> carts = [];
    for (int index = 0; index < _cartList!.length; index++) {
      CartModel cart = _cartList![index]!;
      List<int?> addOnIdList = [];
      List<int?> addOnQtyList = [];
      for (var addOn in cart.addOnIds!) {
        addOnIdList.add(addOn.id);
        addOnQtyList.add(addOn.quantity);
      }

      List<OrderVariation> variations = [];
      if (Get.find<SplashController>().getModuleConfig(cart.item!.moduleType).newVariation!) {
        for (int i = 0; i < cart.item!.foodVariations!.length; i++) {
          if (cart.foodVariations![i].contains(true)) {
            variations.add(OrderVariation(name: cart.item!.foodVariations![i].name, values: OrderVariationValue(label: [])));
            for (int j = 0; j < cart.item!.foodVariations![i].variationValues!.length; j++) {
              if (cart.foodVariations![i][j]!) {
                variations[variations.length - 1].values!.label!.add(cart.item!.foodVariations![i].variationValues![j].level);
              }
            }
          }
        }
      }

      carts.add(OnlineCart(
        cart.id, cart.item!.id, cart.isCampaign! ? cart.item!.id : null,
        cart.discountedPrice.toString(), '',
        Get.find<SplashController>().getModuleConfig(cart.item!.moduleType).newVariation! ? null : cart.variation,
        Get.find<SplashController>().getModuleConfig(cart.item!.moduleType).newVariation! ? variations : null,
        cart.quantity, addOnIdList, cart.addOns, addOnQtyList, 'Item',
        itemType: !widget.fromCart ? "AppModelsItemCampaign" : null,
        note: cart.note,
      ));
    }

    PlaceOrderBodyModel placeOrderBody = PlaceOrderBodyModel(
      cart: carts, couponDiscountAmount: Get.find<CouponController>().discount, distance: checkoutController.distance,
      scheduleAt: !checkoutController.store!.scheduleOrder! ? null : null,
      orderAmount: total, orderNote: checkoutController.noteController.text, orderType: checkoutController.orderType,
      paymentMethod: checkoutController.paymentMethodIndex == 0 ? 'cash_on_delivery'
          : checkoutController.paymentMethodIndex == 1 ? 'wallet'
          : checkoutController.paymentMethodIndex == 2 ? 'digital_payment' : 'offline_payment',
      couponCode: (Get.find<CouponController>().discount! > 0 || (Get.find<CouponController>().coupon != null
          && Get.find<CouponController>().freeDelivery)) ? Get.find<CouponController>().coupon!.code : null,
      storeId: _cartList![0]!.item!.storeId,
      address: finalAddress!.address, latitude: finalAddress.latitude, longitude: finalAddress.longitude,
      senderZoneId: null, addressType: finalAddress.addressType,
      contactPersonName: finalAddress.contactPersonName ?? '${Get.find<ProfileController>().userInfoModel!.fName} '
          '${Get.find<ProfileController>().userInfoModel!.lName}',
      contactPersonNumber: finalAddress.contactPersonNumber ?? Get.find<ProfileController>().userInfoModel!.phone,
      streetNumber: isGuestLogIn ? finalAddress.streetNumber ?? '' : checkoutController.streetNumberController.text.trim(),
      house: isGuestLogIn ? finalAddress.house ?? '' : checkoutController.houseController.text.trim(),
      floor: isGuestLogIn ? finalAddress.floor ?? '' : checkoutController.floorController.text.trim(),
      discountAmount: discount, taxAmount: tax, receiverDetails: null, parcelCategoryId: null,
      chargePayer: null, dmTips: (checkoutController.orderType == 'take_away' || checkoutController.tipController.text == 'not_now') ? '' : checkoutController.tipController.text.trim(),
      cutlery: Get.find<CartController>().addCutlery ? 1 : 0,
      unavailableItemNote: Get.find<CartController>().notAvailableIndex != -1 ? Get.find<CartController>().notAvailableList[Get.find<CartController>().notAvailableIndex] : '',
      deliveryInstruction: checkoutController.selectedInstruction != -1 ? AppConstants.deliveryInstructionList[checkoutController.selectedInstruction] : '',
      partialPayment: checkoutController.isPartialPay ? 1 : 0, guestId: isGuestLogIn ? int.parse(AuthHelper.getGuestId()) : 0,
      isBuyNow: widget.fromCart ? 0 : 1, guestEmail: isGuestLogIn ? finalAddress.email : null,
      extraPackagingAmount: Get.find<CartController>().needExtraPackage ? checkoutController.store!.extraPackagingAmount : 0,
      createNewUser: checkoutController.isCreateAccount ? 1 : 0, password: guestPasswordController.text,
      bringChangeAmount: checkoutController.paymentMethodIndex == 0 && checkoutController.exchangeAmount > 0 ? checkoutController.exchangeAmount : null,
    );

    checkoutController.placeOrder(
      placeOrderBody, checkoutController.store!.zoneId, total, maxCodOrderAmount, widget.fromCart,
      _isCashOnDeliveryActive!, checkoutController.pickedPrescriptions,
      isOfflinePay: checkoutController.paymentMethodIndex == 3,
    );
  }

  /// Calls CheckoutController.placePrescriptionOrder() — identical to the
  /// original inline code.
  void _submitPrescriptionOrder({
    required CheckoutController checkoutController,
    required AddressModel? finalAddress,
    required bool isGuestLogIn,
  }) {
    checkoutController.placePrescriptionOrder(
      storeId: widget.storeId,
      zoneID: checkoutController.store!.zoneId, distance: checkoutController.distance,
      address: finalAddress!.address!, longitude: finalAddress.longitude!,
      latitude: finalAddress.latitude!, note: checkoutController.noteController.text,
      orderAttachment: checkoutController.pickedPrescriptions,
      savedImages: checkoutController.pickedPrescriptionSavedImageNames.whereType<String>().toList(),
      dmTips: (checkoutController.orderType == 'take_away' || checkoutController.tipController.text == 'not_now')
          ? '' : checkoutController.tipController.text.trim(),
      deliveryInstruction: checkoutController.selectedInstruction != -1
          ? AppConstants.deliveryInstructionList[checkoutController.selectedInstruction] : '',
      orderAmount: 0, maxCodAmount: 0, fromCart: widget.fromCart, isCashOnDeliveryActive: _isCashOnDeliveryActive!,
    );
  }

  /// Opens the confirmation dialog. Cancel / outside-tap / back button is
  /// treated as "do nothing" — the order is NEVER submitted in those cases.
  void _showPaymentConfirmationDialog({
    required VoidCallback onConfirm,
    required VoidCallback onChange,
  }) {
    Get.dialog(
      ConfirmPaymentMethodDialog(
        onConfirm: onConfirm,
        onChange: onChange,
      ),
      barrierDismissible: true,
    );
  }

  /// Called when the user taps "Change" inside the dialog. Re-opens the
  /// existing selector without submitting the order. The newly chosen
  /// method will again require explicit confirmation on the next Place-
  /// Order tap (because setPaymentMethod/changeDigitalPaymentName
  /// invalidate the confirmation flag).
  void _reopenPaymentMethodSelector() {
    if (_isCashOnDeliveryActive! || _isDigitalPaymentActive! || _isWalletActive || _isOfflinePaymentActive) {
      if (ResponsiveHelper.isDesktop(Get.context)) {
        Get.dialog(
          Dialog(
            backgroundColor: Colors.transparent,
            child: PaymentMethodBottomSheet(
              isCashOnDeliveryActive: _isCashOnDeliveryActive!,
              isDigitalPaymentActive: _isDigitalPaymentActive!,
              totalPrice: _totalForBottomSheet,
              isOfflinePaymentActive: _isOfflinePaymentActive,
            ),
          ),
        );
      } else {
        Get.bottomSheet(
          PaymentMethodBottomSheet(
            isCashOnDeliveryActive: _isCashOnDeliveryActive!,
            isDigitalPaymentActive: _isDigitalPaymentActive!,
            totalPrice: _totalForBottomSheet,
            isOfflinePaymentActive: _isOfflinePaymentActive,
          ),
          backgroundColor: Colors.transparent,
          isScrollControlled: true,
          useRootNavigator: true,
        );
      }
    } else {
      showCustomSnackBar('no_payment_method_found'.tr);
    }
  }

  /// Snapshot of the current total used by the bottom sheet helper.
  double get _totalForBottomSheet {
    try {
      return Get.find<CheckoutController>().viewTotalPrice ?? 0.0;
    } catch (_) {
      return 0.0;
    }
  }

  /// Called when the user taps "Confirm & Place Order" inside the dialog.
  /// Sets the confirmation flag and immediately runs the submission pipeline.
  void _proceedWithPlaceOrder() {
    Get.find<CheckoutController>().confirmPaymentMethodForCurrentOrder();
    _executeOrderSubmission();
  }

  /// Dispatch helper.
  void _executeOrderSubmission() {
    _runOrderSubmission();
  }

  List<DropdownItem<int>> _getDropdownAddressList({required BuildContext context, required List<AddressModel>? addressList, required Store? store}) {
    List<DropdownItem<int>> dropDownAddressList = [];

    dropDownAddressList.add(DropdownItem<int>(value: 0, child: SizedBox(
      width: context.width > Dimensions.webMaxWidth ? Dimensions.webMaxWidth - 50 : context.width - 50,
      child: AddressWidget(
        address: AddressHelper.getUserAddressFromSharedPref(),
        fromAddress: false, fromCheckout: true,
      ),
    )));

    if(addressList != null && store != null) {
      for(int index=0; index<addressList.length; index++) {
        if(addressList[index].zoneIds!.contains(store.zoneId)) {

          dropDownAddressList.add(DropdownItem<int>(value: index + 1, child: SizedBox(
            width: context.width > Dimensions.webMaxWidth ? Dimensions.webMaxWidth-50 : context.width-50,
            child: AddressWidget(
              address: addressList[index],
              fromAddress: false, fromCheckout: true,
            ),
          )));
        }
      }
    }
    return dropDownAddressList;
  }

  List<AddressModel> _getAddressList({required List<AddressModel>? addressList, required Store? store}) {
    List<AddressModel> address = [];

    if(AddressHelper.getUserAddressFromSharedPref() != null) {
      address.add(AddressHelper.getUserAddressFromSharedPref()!);
    }

    if(addressList != null && store != null) {
      for(int index=0; index<addressList.length; index++) {
        if(addressList[index].zoneIds!.contains(store.zoneId)) {
          address.add(addressList[index]);
        }
      }
    }
    return address;
  }

  Pivot? _getModuleData({required Store? store}) {
    Pivot? moduleData;
    if(store != null) {
      for(ZoneData zData in AddressHelper.getUserAddressFromSharedPref()!.zoneData!) {
        for(Modules m in zData.modules!) {
          if(m.id == Get.find<SplashController>().module?.id && m.pivot!.zoneId == store.zoneId) {
            moduleData = m.pivot;
            break;
          }
        }
      }
    }
    return moduleData;
  }

  bool _checkCODActive({required Store? store}) {
    bool isCashOnDeliveryActive = false;
    if(store != null){
      for(ZoneData zData in AddressHelper.getUserAddressFromSharedPref()!.zoneData!) {
        if(zData.id ==  store.zoneId) {
          isCashOnDeliveryActive = zData.cashOnDelivery! && Get.find<SplashController>().configModel!.cashOnDelivery!;
        }
      }
    }
    return isCashOnDeliveryActive;
  }

  bool _checkDigitalPaymentActive({required Store? store}) {
    bool isDigitalPaymentActive = false;
    if(store != null){
      for(ZoneData zData in AddressHelper.getUserAddressFromSharedPref()!.zoneData!) {
        if(zData.id ==  store.zoneId) {
          isDigitalPaymentActive = zData.digitalPayment! && Get.find<SplashController>().configModel!.digitalPayment!;
        }
      }
    }
    return isDigitalPaymentActive;
  }

  double _calculatePrice({required Store? store, required List<CartModel?>? cartList}) {
    double price = 0;
    if(cartList != null) {
      for (var cartModel in cartList) {
        if(Get.find<SplashController>().getModuleConfig(cartModel!.item!.moduleType).newVariation!){
          price = price + (cartModel.item!.price! * cartModel.quantity!);
        } else {
          price = _calculateVariationPrice(store: store, cartList: cartList);
        }
      }
    }
    return PriceConverter.toFixed(price);
  }

  double _calculateAddonsPrice({required Store? store, required List<CartModel?>? cartList}) {
    double addOns = 0;
    if(store != null && cartList != null) {
      for (var cartModel in cartList) {
        List<AddOns> addOnList = [];
        for (var addOnId in cartModel!.addOnIds!) {
          for (AddOns addOns in cartModel.item!.addOns!) {
            if (addOns.id == addOnId.id) {
              addOnList.add(addOns);
              break;
            }
          }
        }
        for (int index = 0; index < addOnList.length; index++) {
          addOns = addOns + (addOnList[index].price! * cartModel.addOnIds![index].quantity!);
        }
      }
    }
    return PriceConverter.toFixed(addOns);
  }

  double _calculateVariationPrice({required Store? store, required List<CartModel?>? cartList, bool calculateDiscount = false, bool calculateWithoutDiscount = false}) {
    double variationPrice = 0;
    double variationDiscount = 0;
    if(store != null && cartList != null) {
      for (var cartModel in cartList) {
        double? discount = cartModel!.item!.discount;
        String? discountType = cartModel.item!.discountType;

        if(Get.find<SplashController>().getModuleConfig(cartModel.item!.moduleType).newVariation!) {
          isPassedVariationPrice = true;
          for(int index = 0; index< cartModel.item!.foodVariations!.length; index++) {
            for(int i=0; i<cartModel.item!.foodVariations![index].variationValues!.length; i++) {
              if(cartModel.foodVariations![index][i]!) {
                variationPrice += (PriceConverter.convertWithDiscount(cartModel.item!.foodVariations![index].variationValues![i].optionPrice!, discount, discountType, isFoodVariation: true)! * cartModel.quantity!);
                variationDiscount += (cartModel.item!.foodVariations![index].variationValues![i].optionPrice! * cartModel.quantity!);
              }
            }
          }
        } else {

          String variationType = '';
          for(int i=0; i<cartModel.variation!.length; i++) {
            variationType = cartModel.variation![i].type!;
          }

          if(cartModel.item!.variations!.isNotEmpty) {
            for (Variation variation in cartModel.item!.variations!) {
              if (variation.type == variationType) {
                variationPrice += (variation.price! * cartModel.quantity!);
                break;
              }
            }
          } else {
            variationDiscount += (PriceConverter.convertWithDiscount(cartModel.item!.price!, discount, discountType)! * cartModel.quantity!);
            variationPrice += (cartModel.item!.price! * cartModel.quantity!);
          }

        }
      }
    }
    if(calculateDiscount) {
      return (variationDiscount - variationPrice);
    } else if(calculateWithoutDiscount) {
      return variationDiscount;
    } else {
      return variationPrice;
    }
  }

  double _calculateDiscountPrice({required Store? store, required List<CartModel?>? cartList, required double price, required double addOns, required bool calStoreDiscount}) {
    double discount = 0;
    if (store != null && cartList != null && cartList.isNotEmpty) {
      for (var cartModel in cartList) {
        double? dis = (store.discount != null
            && DateConverter.isAvailable(store.discount!.startTime, store.discount!.endTime))
            && calStoreDiscount ? store.discount!.discount : cartModel!.item!.discount;

        String? disType = (store.discount != null
            && DateConverter.isAvailable(store.discount!.startTime, store.discount!.endTime))
            && calStoreDiscount ? 'percent' : cartModel?.item!.discountType;

        if(Get.find<SplashController>().getModuleConfig(cartModel!.item!.moduleType).newVariation!) {
          double d = ((cartModel.item!.price! - PriceConverter.convertWithDiscount(cartModel.item!.price!, dis, disType)!) * cartModel.quantity!);
          discount = discount + d;
          if(disType == 'percent' && discount != 0) {
            discount = discount + _calculateFoodVariationDiscount(cartModel: cartModel);
          }
        } else {
          String variationType = '';
          double variationPrice = 0;
          double variationWithoutDiscountPrice = 0;
          for(int i=0; i<cartModel.variation!.length; i++) {
            variationType = cartModel.variation![i].type!;
          }
          if(cartModel.item!.variations!.isNotEmpty){
            for (Variation variation in cartModel.item!.variations!) {
              if (variation.type == variationType) {
                variationPrice += (PriceConverter.convertWithDiscount(variation.price!, dis, disType)! * cartModel.quantity!);
                variationWithoutDiscountPrice += (variation.price! * cartModel.quantity!);
                break;
              }
            }
            discount = discount + (variationWithoutDiscountPrice - variationPrice);

          } else {
            double d = ((cartModel.item!.price! - PriceConverter.convertWithDiscount(cartModel.item!.price!, dis, disType)!) * cartModel.quantity!);
            discount = discount + d;
          }
        }

      }
    }

    if(calStoreDiscount){
      if (store != null && store.discount != null) {
        if (store.discount!.maxDiscount != 0 && store.discount!.maxDiscount! < discount) {
          discount = store.discount!.maxDiscount!;
        }
        if (store.discount!.minPurchase != 0 && store.discount!.minPurchase! > (price + addOns)) {
          discount = 0;
        }
      }
    }
    return PriceConverter.toFixed(discount);
  }

  double _getDiscountPrice(double storeDiscountPrice, double itemDiscountPrice) {
    double discountPrice = 0;
    if(storeDiscountPrice > itemDiscountPrice) {
      discountPrice = storeDiscountPrice;
    } else if(itemDiscountPrice > storeDiscountPrice) {
      discountPrice = itemDiscountPrice;
    } else {
      discountPrice = itemDiscountPrice;
    }
    return discountPrice;
  }

  double _getExtraDiscountPrice(double storeDiscountPrice, double itemDiscountPrice) {
    double extraDiscount = 0;
    if(storeDiscountPrice > itemDiscountPrice) {
      extraDiscount = storeDiscountPrice - itemDiscountPrice;
    } else if(itemDiscountPrice > storeDiscountPrice) {
      extraDiscount = 0;
    } else {
      extraDiscount = 0;
    }
    return extraDiscount;
  }

  double _calculateFoodVariationDiscount({required CartModel? cartModel}) {
    double variationPrice = 0;
    double variationDiscount = 0;
    if(cartModel != null) {
      double? discount = cartModel.item!.discount;
      String? discountType = cartModel.item!.discountType;
      for (int index = 0; index < cartModel.item!.foodVariations!.length; index++) {
        for (int i = 0; i < cartModel.item!.foodVariations![index].variationValues!.length; i++) {
          if (cartModel.foodVariations![index][i]!) {
            variationPrice += (PriceConverter.convertWithDiscount(
                cartModel.item!.foodVariations![index].variationValues![i].optionPrice!, discount, discountType,
                isFoodVariation: true)! * cartModel.quantity!);
            variationDiscount += (cartModel.item!.foodVariations![index].variationValues![i].optionPrice! * cartModel.quantity!);
          }
        }
      }
    }
    return (variationDiscount - variationPrice);
  }

  double _calculateOrderAmount({required double price, required double variations, required double discount, required double addOns, required double couponDiscount, required List<CartModel?>? cartList, required double referralDiscount}) {
    double orderAmount = 0;
    double variationPrice = 0;
    if(cartList != null && cartList.isNotEmpty && Get.find<SplashController>().getModuleConfig(cartList[0]?.item?.moduleType).newVariation!){
      variationPrice = variations;
    }
    orderAmount = (price + variationPrice - discount) + addOns - couponDiscount - referralDiscount;
    return PriceConverter.toFixed(orderAmount);
  }

  double _calculateSubTotal({required double price, required double addOns, required double variations, required List<CartModel?>? cartList}) {
    double subTotal = 0;
    bool isFoodVariation = false;

    if(cartList != null && cartList.isNotEmpty) {
      isFoodVariation = Get.find<SplashController>().getModuleConfig(cartList[0]!.item!.moduleType).newVariation!;
    }
    if(isFoodVariation){
      subTotal = price + addOns + variations;
    } else {
      subTotal = price;
    }

    return subTotal;
  }

  double _calculateOriginalDeliveryCharge({required Store? store, required AddressModel address, required double? distance, required double? extraCharge, double? surgePrice, String? surgePriceType}) {
    double deliveryCharge = -1;

    Pivot? moduleData;
    if(store != null) {
      for(ZoneData zData in address.zoneData!) {
        for(Modules m in zData.modules!) {
          if(m.id == Get.find<SplashController>().module!.id && m.pivot!.zoneId == store.zoneId) {
            moduleData = m.pivot;
            break;
          }
        }
      }
    }

    double perKmCharge = 0;
    double minimumCharge = 0;
    double maximumCharge = 0;
    if(store != null && distance != null && distance != -1 && store.selfDeliverySystem == 1) {
      perKmCharge = store.perKmShippingCharge ?? 0;
      minimumCharge = store.minimumShippingCharge ?? 0;
      maximumCharge = store.maximumShippingCharge ?? 0;
    }else if(store != null && distance != null && distance != -1 && moduleData != null && moduleData.deliveryChargeType == 'distance') {
      perKmCharge = moduleData.perKmShippingCharge ?? 0;
      minimumCharge = moduleData.minimumShippingCharge ?? 0;
      maximumCharge = moduleData.maximumShippingCharge ?? 0;
    } else if(store != null && moduleData != null && moduleData.deliveryChargeType == 'fixed') {
      perKmCharge = moduleData.fixedShippingCharge ?? 0;
      minimumCharge = moduleData.fixedShippingCharge ?? 0;
      maximumCharge = moduleData.fixedShippingCharge ?? 0;
      if (kDebugMode) {
        print('Fixed shipping charge perKmCharge, minimumCharge, maximumCharge :: $perKmCharge, $minimumCharge, $maximumCharge');
      }
    }

    if(store != null && distance != null) {
      deliveryCharge = distance * perKmCharge;
      if (kDebugMode) {
        print('distance * perKmCharge = $deliveryCharge');
      }

      if(deliveryCharge < minimumCharge) {
        if (kDebugMode) {
          print('minimumCharge $minimumCharge');
        }
        deliveryCharge = minimumCharge;
        if (kDebugMode) {
          print('minimumCharge 2 $deliveryCharge');
        }
      }else if(maximumCharge > 0 && deliveryCharge > maximumCharge) {
        if (kDebugMode) {
          print('maximumCharge $deliveryCharge');
        }
        deliveryCharge = maximumCharge;
        if (kDebugMode) {
          print('maximumCharge 2 $maximumCharge');
        }
      }
    }

    if(store != null && store.selfDeliverySystem == 0 && extraCharge != null) {
      extraChargeForToolTip = extraCharge;
      deliveryCharge = deliveryCharge + extraCharge;
      if (kDebugMode) {
        print('extraCharge $deliveryCharge');
      }
    }

    if(store != null && store.selfDeliverySystem == 0 && surgePrice != null && surgePrice > 0) {
      if(surgePriceType == 'percent') {
        badWeatherChargeForToolTip = (deliveryCharge * (surgePrice/100));
        if (kDebugMode) {
          print('badWeatherChargeForToolTip $badWeatherChargeForToolTip');
        }
        deliveryCharge = deliveryCharge + (deliveryCharge * (surgePrice/100));
        if (kDebugMode) {
          print('(deliveryCharge * (surgePrice/100)) $deliveryCharge');
        }
      } else {
        badWeatherChargeForToolTip = surgePrice;
        if (kDebugMode) {
          print('badWeatherChargeForToolTip $badWeatherChargeForToolTip 2');
        }
        deliveryCharge = deliveryCharge + surgePrice;
        if (kDebugMode) {
          print('deliveryCharge + surgePrice $deliveryCharge');
        }
      }
    }

    return deliveryCharge;
  }

  double _calculateTotal({
    required double subTotal, required double deliveryCharge, required double discount,
    required double couponDiscount, required bool taxIncluded, required double tax,
    required String orderType, required double tips, required double additionalCharge, required double extraPackagingCharge,
  }) {

    // deliveryCharge == -1 is the in-band "still calculating" sentinel
    // coming out of DeliveryFeeResolver. We must not add -1 to the total
    // (it would produce a negative value while the async distance / extra
    // charge are still being fetched).
    final double effectiveDeliveryCharge = deliveryCharge < 0 ? 0.0 : deliveryCharge;

    return PriceConverter.toFixed(
        subTotal + effectiveDeliveryCharge - discount- couponDiscount + (taxIncluded ? 0 : tax)
            + ((orderType != 'take_away' && Get.find<SplashController>().configModel!.dmTipsStatus == 1) ? tips : 0)
            + additionalCharge + extraPackagingCharge
    );
  }

  bool _checkZoneOfflinePaymentOnOff({required AddressModel? addressModel, required CheckoutController checkoutController}) {
    bool? status = false;
    ZoneData? zoneData;
    for (var data in addressModel!.zoneData!) {
      if(data.id == checkoutController.store?.zoneId) {
        zoneData = data;
        break;
      }
    }
    status = zoneData?.offlinePayment ?? false;
    return status;
  }

  bool _checkPrescriptionRequired() {
    if(widget.storeId == null && Get.find<SplashController>().configModel!.moduleConfig!.module!.orderAttachment!) {
      for (var cart in _cartList!) {
        if(cart!.item!.isPrescriptionRequired!) {
          return true;
        }
      }
    }
    return false;
  }

  double _calculateExtraPackagingCharge(CheckoutController checkoutController) {
    if((checkoutController.store?.extraPackagingStatus ?? true) && (Get.find<CartController>().needExtraPackage)) {
      return checkoutController.store?.extraPackagingAmount ?? 0;
    }
    return 0;
  }

  double _calculateReferralDiscount(double subTotal, double discount, double couponDiscount) {
    double referralDiscount = 0;
    if(Get.find<ProfileController>().userInfoModel != null &&  Get.find<ProfileController>().userInfoModel!.isValidForDiscount!) {
      if (Get.find<ProfileController>().userInfoModel!.discountAmountType! == "percentage") {
        referralDiscount = (Get.find<ProfileController>().userInfoModel!.discountAmount! / 100) * (subTotal - discount - couponDiscount);
      } else {
        referralDiscount = Get.find<ProfileController>().userInfoModel!.discountAmount!;
      }
    }
    return PriceConverter.toFixed(referralDiscount);
  }

  Future<void> showCashBackSnackBar(double amount) async {
    await Get.find<HomeController>().getCashBackData(amount);
    double? cashBackAmount = Get.find<HomeController>().cashBackData?.cashbackAmount ?? 0;
    String? cashBackType = Get.find<HomeController>().cashBackData?.cashbackType ?? '';
    String text = '${'you_will_get'.tr} ${cashBackType == 'amount' ? PriceConverter.convertPrice(cashBackAmount) : '${cashBackAmount.toStringAsFixed(0)}%'} ${'cash_back_after_completing_order'.tr}';
    if(cashBackAmount > 0) {
      showCustomSnackBar(text, isError: false);
    }
  }

}