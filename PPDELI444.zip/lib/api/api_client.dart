import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:path/path.dart';
import 'package:file_picker/file_picker.dart';
import 'package:get/get_connect/http/src/request/request.dart';
import 'package:http_parser/http_parser.dart';
import 'package:pickles_and_pies/api/api_checker.dart';
import 'package:pickles_and_pies/features/address/domain/models/address_model.dart';
import 'package:pickles_and_pies/common/models/error_response.dart';
import 'package:pickles_and_pies/common/models/module_model.dart';
import 'package:pickles_and_pies/helper/responsive_helper.dart';
import 'package:pickles_and_pies/util/app_constants.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';

class ApiClient extends GetxService {
  final String appBaseUrl;
  final SharedPreferences sharedPreferences;
  static final String noInternetMessage = 'connection_to_api_server_failed'.tr;
  final int timeoutInSeconds = 15;

  String? token;
  Map<String, String> _mainHeaders = const {};

  /// Cached pre-encoded values to avoid `jsonEncode` on every API call.
  String? _cachedZoneIdsEncoded;
  String? _cachedLatitudeEncoded;
  String? _cachedLongitudeEncoded;

  /// Fingerprint of the last header build so we can skip recomputation when
  /// none of the inputs changed.
  String? _lastHeaderFingerprint;

  ApiClient({required this.appBaseUrl, required this.sharedPreferences}) {
    token = sharedPreferences.getString(AppConstants.token);
    if (kDebugMode) {
      print('Token: $token');
    }
    AddressModel? addressModel;
    try {
      addressModel = AddressModel.fromJson(jsonDecode(sharedPreferences.getString(AppConstants.userAddress)!));
    } catch (_) {}
    int? moduleID;
    if (GetPlatform.isWeb && sharedPreferences.containsKey(AppConstants.moduleId)) {
      try {
        moduleID = ModuleModel.fromJson(jsonDecode(sharedPreferences.getString(AppConstants.moduleId)!)).id;
      } catch (_) {}
    }
    updateHeader(token, addressModel?.zoneIds, addressModel?.areaIds, sharedPreferences.getString(AppConstants.languageCode),
      moduleID?.toString(), addressModel?.latitude, addressModel?.longitude, null);
  }

  Map<String, String> updateHeader(String? token, List<int>? zoneIDs, List<int>? operationIds, String? languageCode, String? moduleID,
      String? latitude, String? longitude, int? zoneId, {bool setHeader = true, fromModule = false,
  }) {
    // Build a compact fingerprint of the inputs. If it matches the last
    // computation we can safely return the cached headers without re-running
    // jsonEncode / SharedPreferences lookups.
    final fingerprint = '${token ?? ''}|${zoneId ?? ''}|$fromModule|'
        '${languageCode ?? ''}|${moduleID ?? ''}|'
        '${zoneIDs?.join(',') ?? ''}|${operationIds?.join(',') ?? ''}|'
        '$latitude|$longitude';

    if (setHeader &&
        _lastHeaderFingerprint != null &&
        _lastHeaderFingerprint == fingerprint &&
        _mainHeaders.isNotEmpty) {
      return _mainHeaders;
    }

    // Encode the JSON values only when something has changed.
    final zoneIdsEncoded = (zoneId != null && fromModule)
        ? '$zoneId'
        : (zoneIDs != null ? _encodeZoneIds(zoneIDs) : '');
    final latitudeEncoded = latitude != null ? _encodeLatitude(latitude) : '';
    final longitudeEncoded = longitude != null ? _encodeLongitude(longitude) : '';

    // Resolve the module id without re-decoding on every call.
    String? resolvedModuleId = moduleID;
    if (resolvedModuleId == null) {
      final cached = sharedPreferences.getString(AppConstants.cacheModuleId);
      if (cached != null) {
        try {
          resolvedModuleId = '${ModuleModel.fromJson(jsonDecode(cached)).id}';
        } catch (_) {}
      }
    }

    final header = <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
      AppConstants.zoneId: zoneIdsEncoded,
      // AppConstants.operationAreaId: operationIds != null ? jsonEncode(operationIds) : '',
      AppConstants.localizationKey:
          languageCode ?? AppConstants.languages[0].languageCode!,
      AppConstants.latitude: latitudeEncoded,
      AppConstants.longitude: longitudeEncoded,
      'Authorization': 'Bearer $token',
    };
    if (resolvedModuleId != null) {
      header[AppConstants.moduleId] = resolvedModuleId;
    }

    if (setHeader) {
      _mainHeaders = header;
      _lastHeaderFingerprint = fingerprint;
    }
    return header;
  }

  Map<String, String> getHeader() => _mainHeaders;

  String _encodeZoneIds(List<int> zoneIDs) {
    final joined = zoneIDs.join(',');
    final cached = _cachedZoneIdsEncoded;
    if (cached != null && _lastZoneIdsJoined == joined) return cached;
    _lastZoneIdsJoined = joined;
    return _cachedZoneIdsEncoded = jsonEncode(zoneIDs);
  }

  String _encodeLatitude(String latitude) {
    if (_cachedLatitudeEncoded == latitude) return _cachedLatitudeEncoded!;
    return _cachedLatitudeEncoded = jsonEncode(latitude);
  }

  String _encodeLongitude(String longitude) {
    if (_cachedLongitudeEncoded == longitude) return _cachedLongitudeEncoded!;
    return _cachedLongitudeEncoded = jsonEncode(longitude);
  }

  String? _lastZoneIdsJoined;

  Future<Response> getData(String uri, {Map<String, dynamic>? query, Map<String, String>? headers, bool handleError = true}) async {
    try {
      if (kDebugMode) {
        log('====> API Call: $uri\nHeader: ${headers ?? _mainHeaders}');
      }
      http.Response response = await http.get(Uri.parse(appBaseUrl + uri), headers: headers ?? _mainHeaders).timeout(Duration(seconds: timeoutInSeconds));
      return handleResponse(response, uri, handleError);
    } catch (e) {
      if (kDebugMode) {
        print('------------${e.toString()}');
      }
      return Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Future<Response> postData(String uri, dynamic body, {Map<String, String>? headers, int? timeout, bool handleError = true,}) async {
    try {
      if (kDebugMode) {
        print('====> API Call: $uri\nHeader: ${headers ?? _mainHeaders}');
        print('====> API Body: $body');
      }

      Map<dynamic, dynamic> newBody = {};
      if (body != null) {
        body.forEach((key, value) {
          if (value != null && value.toString().isNotEmpty) {
            newBody.addAll({key: value});
          }
        });
      }

      http.Response response = await http.post(
        Uri.parse(appBaseUrl + uri),
        body: jsonEncode(newBody), headers: headers ?? _mainHeaders).timeout(Duration(seconds: timeout ?? timeoutInSeconds)
      );
      return handleResponse(response, uri, handleError);
    } catch (e) {
      return Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Future<Response> postMultipartData(
    String uri,
    Map<String, String> body,
    List<MultipartBody> multipartBody, {
    List<MultipartDocument>? multipartDoc,
    Map<String, String>? headers,
    bool handleError = true,
  }) async {
    try {
      debugPrint('====> API Call: $uri\nHeader: $_mainHeaders');
      debugPrint(
        '====> API Body: $body with ${multipartBody.length} and multipart ${multipartDoc?.length}',
      );
      http.MultipartRequest request = http.MultipartRequest(
        'POST',
        Uri.parse(appBaseUrl + uri),
      );
      final Map<String, String> multipartHeaders = Map<String, String>.from(headers ?? _mainHeaders);
      multipartHeaders.removeWhere((key, value) => key.toLowerCase() == 'content-type');
      request.headers.addAll(multipartHeaders);
      for (MultipartBody multipart in multipartBody) {
        if (multipart.file != null) {
          if (kIsWeb) {
            Uint8List bytes = await multipart.file!.readAsBytes();

            http.MultipartFile part = http.MultipartFile.fromBytes(multipart.key, bytes, filename: 'image.jpg', contentType: MediaType('image', 'jpeg'));

            request.files.add(part);
          } else {
            File file = File(multipart.file!.path);
            request.files.add(
              http.MultipartFile(multipart.key, file.readAsBytes().asStream(), file.lengthSync(), filename: file.path.split('/').last),
            );
          }
        }
      }

      if (multipartDoc != null && multipartDoc.isNotEmpty) {
        for (MultipartDocument file in multipartDoc) {
          if (kIsWeb) {
            PlatformFile platformFile = file.file!.files.first;
            request.files.add(
              http.MultipartFile.fromBytes(file.key, platformFile.bytes!, filename: platformFile.name),
            );
          } else {
            File other = File(file.file!.files.single.path!);
            Uint8List list0 = await other.readAsBytes();
            var part = http.MultipartFile(file.key, other.readAsBytes().asStream(), list0.length, filename: basename(other.path));
            request.files.add(part);
          }
        }
      }

      request.fields.addAll(body);
      http.Response response = await http.Response.fromStream(await request.send());
      return handleResponse(response, uri, handleError);
    } catch (e) {
      return Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Future<Response> putData(
    String uri,
    dynamic body, {Map<String, String>? headers, bool handleError = true}) async {
    try {
      if (kDebugMode) {
        print('====> API Call: $uri\nHeader: ${headers ?? _mainHeaders}');
        print('====> API Body: $body');
      }
      http.Response response = await http.put(Uri.parse(appBaseUrl + uri), body: jsonEncode(body), headers: headers ?? _mainHeaders).timeout(Duration(seconds: timeoutInSeconds));
      return handleResponse(response, uri, handleError);
    } catch (e) {
      return Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Future<Response> deleteData(
    String uri, {
    Map<String, String>? headers,
    bool handleError = true,
  }) async {
    try {
      if (kDebugMode) {
        print('====> API Call: $uri\nHeader: ${headers ?? _mainHeaders}');
      }
      http.Response response = await http
          .delete(Uri.parse(appBaseUrl + uri), headers: headers ?? _mainHeaders)
          .timeout(Duration(seconds: timeoutInSeconds));
      return handleResponse(response, uri, handleError);
    } catch (e) {
      return Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Response handleResponse(
    http.Response response,
    String uri,
    bool handleError,
  ) {
    dynamic body;
    try {
      body = jsonDecode(response.body);
    } catch (_) {}
    Response response0 = Response(
      body: body ?? response.body,
      bodyString: response.body.toString(),
      request: Request(
        headers: response.request!.headers,
        method: response.request!.method,
        url: response.request!.url,
      ),
      headers: response.headers,
      statusCode: response.statusCode,
      statusText: response.reasonPhrase,
    );
    if (response0.statusCode != 200 &&
        response0.body != null &&
        response0.body is! String) {
      if (response0.body.toString().startsWith('{errors: [{code:')) {
        ErrorResponse errorResponse = ErrorResponse.fromJson(response0.body);
        response0 = Response(
          statusCode: response0.statusCode,
          body: response0.body,
          statusText: errorResponse.errors![0].message,
        );
      } else if (response0.body.toString().startsWith('{response_code: zone_404, message:')) {
        response0 = Response(statusCode: response0.statusCode, body: response0.body, statusText: response0.body['message']);
      } else if(response0.body.toString().startsWith('{response_code: route_404, message:')) {
        response0 = Response(statusCode: response0.statusCode, body: response0.body, statusText: response0.body['message']);
      }else if (response0.body.toString().startsWith('{message')) {
        response0 = Response(statusCode: response0.statusCode, body: response0.body, statusText: response0.body['message']);
      }
    } else if (response0.statusCode != 200 && response0.body == null) {
      response0 = Response(statusCode: 0, statusText: noInternetMessage);
    }
    if (kDebugMode) {
      print('====> API Response: [${response0.statusCode}] $uri');
      if (!ResponsiveHelper.isWeb() || response.statusCode != 500) {
        log('====> API Response Body: ${response0.body}');
      }
    }
    if (handleError) {
      if (response0.statusCode == 200) {
        return response0;
      } else {
        ApiChecker.checkApi(response0);
        return const Response();
      }
    } else {
      return response0;
    }
  }
}

class MultipartBody {
  String key;
  XFile? file;

  MultipartBody(this.key, this.file);
}

class MultipartDocument {
  String key;
  FilePickerResult? file;
  MultipartDocument(this.key, this.file);
}
